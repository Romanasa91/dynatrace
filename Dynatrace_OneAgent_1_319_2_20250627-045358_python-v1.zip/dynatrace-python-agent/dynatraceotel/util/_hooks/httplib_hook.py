from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class HttpClientInstrumentationHook(BaseInstrumentationHook):
    library_name = "http.client"
    version_specifiers = ""

    def _get_library_version(self, mod: ModuleType) -> str:
        return ""

    def _instrument(self, mod: ModuleType):
        from dynatraceotel.util.http.httplib import (  # pylint: disable=import-outside-toplevel
            HttpClientInstrumentor,
        )

        HttpClientInstrumentor().instrument()

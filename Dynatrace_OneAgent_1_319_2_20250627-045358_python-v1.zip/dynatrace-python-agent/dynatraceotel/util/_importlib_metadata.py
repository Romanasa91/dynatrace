# Copyright The OpenTelemetry Authors
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from importlib.metadata import (
    Distribution,
    PackageNotFoundError,
    distributions,
    requires,
    version,
)
from sys import version_info

if version_info.minor in (8, 9):
    # DT: in python 3.8 and 3.9 'entry_points' returns a dict. For a unified API
    #   the 'EntryPoints' class is (partly) copied from a later release
    #   https://github.com/python/importlib_metadata/blob/v6.1.0/importlib_metadata/__init__.py#L277
    #

    import itertools
    from importlib.metadata import EntryPoint
    from importlib.metadata import entry_points as _importlib_entry_points

    def _matches_ep(entry_point: EntryPoint, **params) -> bool:
        return (
            params.get("name", entry_point.name) == entry_point.name
            and params.get("group", entry_point.group) == entry_point.group
            and params.get("value", entry_point.value) == entry_point.value
        )

    class EntryPoints(tuple):
        __slots__ = ()

        def __getitem__(self, name):  # -> EntryPoint:
            try:
                return next(iter(self.select(name=name)))
            except StopIteration:
                raise KeyError(name)

        def select(self, **params):
            return EntryPoints(
                ept for ept in self if _matches_ep(ept, **params)
            )

        @property
        def names(self):
            return {ep.name for ep in self}

        @property
        def groups(self):
            return {ep.group for ep in self}

    def entry_points(**params) -> EntryPoints:
        eps = itertools.chain.from_iterable(_importlib_entry_points().values())
        return EntryPoints(eps).select(**params)

elif version_info.minor in (10, 11):
    # DT: in 3.10 and 3.11 when called without parameters 'entry_points' returns
    #   a dict-like (SelectableGroups) object. Called with parameters a list-like
    #   (EntryPoints) object is returned. For a unified API the SelectableGroups
    #   return value is avoided and always the 'EntryPoints' object is returned.

    from importlib.metadata import (  # pylint:disable=no-name-in-module
        EntryPoint,
        EntryPoints,
        SelectableGroups,
    )
    from importlib.metadata import (
        entry_points as _importlib_entry_points,  # pylint:disable=no-name-in-module
    )

    def entry_points(**params) -> EntryPoints:
        eps = _importlib_entry_points(**params)
        if isinstance(eps, SelectableGroups):
            return getattr(eps, "_all")
        return eps

else:
    from importlib.metadata import (  # pylint:disable=no-name-in-module
        EntryPoint,
        EntryPoints,
        entry_points,
    )

__all__ = [
    "entry_points",
    "version",
    "EntryPoint",
    "EntryPoints",
    "requires",
    "Distribution",
    "distributions",
    "PackageNotFoundError",
]

from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class AioHttpClientInstrumentationHook(BaseInstrumentationHook):
    library_name = "aiohttp"
    version_specifiers = "~= 3.0"

    def _get_library_version(self, mod: ModuleType) -> str:
        return mod.__version__

    def _instrument(self, mod: ModuleType):
        from dynatraceotel.instrumentation.aiohttp_client import (  # pylint: disable=import-outside-toplevel
            AioHttpClientInstrumentor,
        )

        AioHttpClientInstrumentor().instrument()

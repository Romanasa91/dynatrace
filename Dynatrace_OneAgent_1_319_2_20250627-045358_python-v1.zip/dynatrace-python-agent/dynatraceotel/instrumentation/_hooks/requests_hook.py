from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class RequestsInstrumentationHook(BaseInstrumentationHook):
    library_name = "requests"
    version_specifiers = "~= 2.0"

    def _get_library_version(self, mod: ModuleType) -> str:
        return mod.__version__

    def _instrument(self, mod: ModuleType):
        from dynatraceotel.instrumentation.requests import (  # pylint: disable=import-outside-toplevel
            RequestsInstrumentor,
        )

        RequestsInstrumentor().instrument()

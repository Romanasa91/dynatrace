from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class UrlLib3InstrumentationHook(BaseInstrumentationHook):
    library_name = "urllib3"
    version_specifiers = ">= 1.0.0, < 3"

    def _get_library_version(self, mod: ModuleType) -> str:
        return mod.__version__

    def _instrument(self, mod: ModuleType):
        from dynatraceotel.instrumentation.urllib3 import (  # pylint: disable=import-outside-toplevel
            URLLib3Instrumentor,
        )

        URLLib3Instrumentor().instrument()

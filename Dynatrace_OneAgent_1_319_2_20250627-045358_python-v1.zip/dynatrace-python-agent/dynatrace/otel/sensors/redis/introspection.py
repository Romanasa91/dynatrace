import enum
import inspect
import sys
from contextlib import contextmanager
from logging import Logger
from typing import (
    Any,
    Callable,
    Dict,
    Iterator,
    List,
    NamedTuple,
    Optional,
    Sequence,
)
from urllib.parse import unquote, urlparse

from dynatrace.odin.semconv import v1 as semconv
from dynatrace.opentelemetry.tracing._util.context import suppressed_tracing
from dynatrace.opentelemetry.tracing._util.exceptions import record_exception
from dynatraceotel.trace import SpanKind, Tracer
from dynatraceotel.trace.span import Span
from dynatraceotel.util.types import AttributeValue

_Attributes = Dict[str, AttributeValue]
_WrapperT = Callable[..., Any]
_CommandT = str
_ArgsT = Sequence[Any]
_KwargsT = Dict[str, Any]

_REDIS_DEFAULT_PORT = 6379
_ATTR_KEY_HOST_AND_PORT = "_dt_host_and_port"


class _CallContext:
    def __init__(self, client: Any, args: _ArgsT, kwargs: _KwargsT) -> None:
        # (client, cluster, asyncio) Redis, Pipeline, ClusterPipeline
        self.client = client
        self.args = args
        self.kwargs = kwargs
        self.command_stack_spans = []
        self.all_spans = []


class _HostAndPort(NamedTuple):
    host: Optional[str]
    port: Optional[int]


class ExecType(enum.Enum):
    STANDARD = enum.auto()
    PIPELINE = enum.auto()


class RedisIntrospection:
    def __init__(
        self, logger: Logger, tracer: Tracer, exec_type: ExecType
    ) -> None:
        self._logger = logger
        self._tracer = tracer
        self._exec_type = exec_type

    @classmethod
    def pipeline(cls, logger: Logger, tracer: Tracer) -> "RedisIntrospection":
        return cls(logger, tracer, ExecType.PIPELINE)

    @classmethod
    def standard(cls, logger: Logger, tracer: Tracer) -> "RedisIntrospection":
        return cls(logger, tracer, ExecType.STANDARD)

    @staticmethod
    def make_cluster_init_wrapper(logger: Logger) -> _WrapperT:
        def _wrapper(wrapped, instance, args, kwargs):
            _extract_host_and_port_from_kwargs_and_set_connection_args(
                logger, wrapped, instance, args, kwargs
            )
            return wrapped(*args, **kwargs)

        return _wrapper

    @staticmethod
    def make_pipeline_func_wrapper(logger: Logger) -> _WrapperT:
        def _wrapper(wrapped, instance, args, kwargs):
            result = wrapped(*args, **kwargs)

            host_and_port = getattr(instance, _ATTR_KEY_HOST_AND_PORT, None)
            _try_set_host_and_port_attr(logger, result, host_and_port)

            return result

        return _wrapper

    def make_sync_wrapper(self) -> _WrapperT:
        def _wrapper(wrapped, instance, args, kwargs):
            ctx = _CallContext(instance, args, kwargs)
            with self._traced_execute(ctx):
                response = wrapped(*args, **kwargs)
                self._handle_response(ctx, response)
                return response

        return _wrapper

    def make_async_wrapper(self) -> _WrapperT:
        async def _wrapper(wrapped, instance, args, kwargs):
            ctx = _CallContext(instance, args, kwargs)
            with self._traced_execute(ctx):
                response = await wrapped(*args, **kwargs)
                self._handle_response(ctx, response)
                return response

        return _wrapper

    @contextmanager
    def _traced_execute(self, ctx: _CallContext) -> Iterator[None]:
        self._start_spans(ctx)
        try:
            with suppressed_tracing():
                yield
        finally:
            ex = sys.exc_info()[1]
            for span in ctx.all_spans:
                record_exception(span, ex)
                span.end()

    def _handle_response(self, ctx: _CallContext, response: Any):
        if self._exec_type != ExecType.PIPELINE:
            return

        if isinstance(response, Sequence) and len(response) == len(
            ctx.command_stack_spans
        ):
            for value, span in zip(response, ctx.command_stack_spans):
                record_exception(span, value)

    def _start_spans(self, ctx: _CallContext) -> None:
        try:
            commands = self._get_commands(ctx)
            if not commands:
                return

            attrs = self._prepare_attributes(ctx)

            transacted = self._is_transacted(ctx)
            if transacted:
                ctx.all_spans.append(self._start_span("MULTI", attrs))

            for command in commands:
                span = self._start_span(command, attrs)
                ctx.all_spans.append(span)
                ctx.command_stack_spans.append(span)

            if transacted:
                ctx.all_spans.append(self._start_span("EXEC", attrs))

        except Exception as ex:  # pylint:disable=broad-except
            self._logger.error("Error while creating spans", exc_info=ex)

    def _prepare_attributes(self, ctx: _CallContext) -> _Attributes:
        host, port = self._get_host_and_port_from(ctx)
        attrs = {
            semconv.DB_SYSTEM: semconv.DbSystemValues.REDIS.value,
        }
        if host:
            attrs[semconv.NET_PEER_NAME] = host
        if port:
            attrs[semconv.NET_PEER_PORT] = port

        return attrs

    def _start_span(self, command: str, attrs: _Attributes) -> Span:
        attrs = attrs.copy()
        attrs[semconv.DB_OPERATION] = command
        return self._tracer.start_span(
            command, kind=SpanKind.CLIENT, attributes=attrs
        )

    @staticmethod
    def _get_host_and_port_from(ctx: _CallContext) -> _HostAndPort:
        connection_pool = getattr(ctx.client, "connection_pool", None)
        if not connection_pool:
            host_and_port = getattr(ctx.client, _ATTR_KEY_HOST_AND_PORT, None)
            return host_and_port if host_and_port else _HostAndPort(None, None)
        conn_kwargs = connection_pool.connection_kwargs
        return _HostAndPort(
            conn_kwargs.get("host", "localhost"), conn_kwargs.get("port", None)
        )

    def _get_commands(self, ctx: _CallContext) -> List[_CommandT]:
        if self._exec_type == ExecType.STANDARD:
            return [self._get_command_name_from(ctx.args)]

        command_stack = (
            getattr(ctx.client, "command_stack", None)
            # asyncio.ClusterPipeline
            or getattr(ctx.client, "_command_stack", ())
        )
        commands = []
        for cmd in command_stack:
            cmd_args = (
                cmd.args  # cluster.ClusterPipeline, asyncio.ClusterPipeline
                if hasattr(cmd, "args")
                else cmd[0]  # client.Pipeline, asyncio.Pipeline
            )
            commands.append(self._get_command_name_from(cmd_args))

        return commands

    @staticmethod
    def _get_command_name_from(cmd_args: Sequence) -> str:
        return cmd_args[0] if len(cmd_args) > 0 else "<Unknown>"

    def _is_transacted(self, ctx: _CallContext) -> bool:
        if self._exec_type == ExecType.STANDARD:
            return False

        transaction_attrs = (
            "transaction",  # client.Pipeline
            "is_transaction",  # asyncio.Pipeline
            "explicit_transaction",  # client.Pipeline, asyncio.Pipeline
        )
        for attr in transaction_attrs:
            value = getattr(ctx.client, attr, False)
            if value and isinstance(value, bool):
                return True
        return False


def _extract_host_and_port_from_kwargs_and_set_connection_args(
    logger: Logger,
    wrapper: _WrapperT,
    instance: Any,
    args: _ArgsT,
    kwargs: _KwargsT,
):
    try:
        sig = inspect.signature(wrapper)
        bound_attrs = sig.bind(*args, **kwargs)

        def _getter(key: str, default: Optional[Any] = None) -> Any:
            attr = bound_attrs.kwargs.get(key, None)
            return (
                attr
                if attr is not None
                else bound_attrs.arguments.get(key, default)
            )

        host_and_port = _host_and_port_from_cluster_kwargs(_getter)
        _try_set_host_and_port_attr(logger, instance, host_and_port)
    except Exception as ex:  # pylint: disable=broad-except
        logger.warning(
            "Could not get host/port from %s: %r", type(instance), ex
        )


def _host_and_port_from_cluster_kwargs(
    get_arg: Callable[..., Any],
) -> Optional[_HostAndPort]:
    startup_nodes = get_arg("startup_nodes")
    if isinstance(startup_nodes, Sequence) and len(startup_nodes) > 0:
        node = startup_nodes[0]
        host = getattr(node, "host", None)
        if not host:
            return None
        return _HostAndPort(host, getattr(node, "port", None))
    url = get_arg("url")
    if url is not None:
        url = urlparse(url)
        if not url.hostname:
            return None

        port = url.port or _REDIS_DEFAULT_PORT
        try:
            port = int(port)
        except (TypeError, ValueError):
            port = None

        return _HostAndPort(unquote(url.hostname), port)

    host = get_arg("host")
    if host:
        return _HostAndPort(host, get_arg("port", _REDIS_DEFAULT_PORT))

    return None


def _try_set_host_and_port_attr(
    logger: Logger, instance: Any, host_and_port: _HostAndPort
):
    try:
        setattr(instance, _ATTR_KEY_HOST_AND_PORT, host_and_port)
    except AttributeError as ex:
        logger.warning(
            "Could not set host and port on instance of %s: %s",
            type(instance),
            ex,
        )

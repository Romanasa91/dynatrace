from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class RedisInstrumentationHook(BaseInstrumentationHook):
    library_name = "redis"
    version_specifiers = "~=5.0"  # TODO v5 is what we need for our use case, but OTel supports >=2.7

    def _get_library_version(self, mod: ModuleType) -> str:
        return mod.__version__

    def _instrument(self, mod: ModuleType) -> None:
        from dynatrace.otel.sensors.redis.instrumentation import (  # pylint: disable=import-outside-toplevel
            RedisInstrumentor,
        )

        RedisInstrumentor().instrument()

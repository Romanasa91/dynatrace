from typing import Collection

import redis

from dynatrace.opentelemetry.tracing._logging.loggers import (
    redis_logger as logger,
)
from dynatrace.opentelemetry.tracing._otel.api import Tracer
from dynatrace.otel.sensors.redis.introspection import RedisIntrospection
from dynatrace.otel.sensors.redis.package import _instruments
from dynatrace.otel.util.transform import Transformer
from dynatraceotel.instrumentation.instrumentor import BaseInstrumentor
from dynatraceotel.trace import get_tracer

_INSTRUMENTATION_LIB_NAME = "dt.agent.python.redis"


class RedisInstrumentor(BaseInstrumentor):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        tracer = get_tracer(_INSTRUMENTATION_LIB_NAME, "")
        self._transformer = Transformer(logger, "redis", redis.__version__)
        _setup_transformer(self._transformer, tracer)

    def instrumentation_dependencies(self) -> Collection[str]:
        return _instruments

    def _instrument(self, **kwargs):
        self._transformer.apply()

    def _uninstrument(self, **kwargs):
        self._transformer.restore()


def _setup_transformer(transformer: Transformer, tracer: Tracer) -> None:
    redis_class, pipeline_class = (
        ("StrictRedis", "BasePipeline")
        if transformer.matches_version_spec("<3.0.0")
        else ("Redis", "Pipeline")
    )

    standard_wrapper = RedisIntrospection.standard(
        logger, tracer
    ).make_sync_wrapper()
    pipeline_wrapper = RedisIntrospection.pipeline(
        logger, tracer
    ).make_sync_wrapper()

    transformer.with_class_func(
        f"redis.client.{redis_class}.execute_command"
    ).use(standard_wrapper)
    transformer.with_class_func(f"redis.client.{pipeline_class}.execute").use(
        pipeline_wrapper
    )
    transformer.with_class_func(
        f"redis.client.{pipeline_class}.immediate_execute_command"
    ).use(standard_wrapper)

    if transformer.matches_version_spec("<4.1.0"):  # redis cluster support
        return

    # RedisCluster does not retain information about the initial contact point, but we want
    # to use that as stable identifier of a cluster connection, so we add code to
    # retain this, resulting in the following information flow:
    #
    # (a) RedisCluster.__init__ (into RedisCluster object) -> pipeline (into Pipeline object) -> execute
    # (b)                                                  -> single command
    cluster_init_wrapper = RedisIntrospection.make_cluster_init_wrapper(logger)
    cluster_pipeline_func_wrapper = (
        RedisIntrospection.make_pipeline_func_wrapper(logger)
    )

    transformer.with_class_func("redis.cluster.RedisCluster.__init__").use(
        cluster_init_wrapper
    )
    transformer.with_class_func("redis.cluster.RedisCluster.pipeline").use(
        cluster_pipeline_func_wrapper
    )
    transformer.with_class_func(
        "redis.cluster.RedisCluster.execute_command"
    ).use(standard_wrapper)
    transformer.with_class_func("redis.cluster.ClusterPipeline.execute").use(
        pipeline_wrapper
    )

    if transformer.matches_version_spec("<4.2.0"):  # asyncio support
        return

    async_standard_wrapper = RedisIntrospection.standard(
        logger, tracer
    ).make_async_wrapper()
    async_pipeline_wrapper = RedisIntrospection.pipeline(
        logger, tracer
    ).make_async_wrapper()

    transformer.with_class_func("redis.asyncio.Redis.execute_command").use(
        async_standard_wrapper
    )
    transformer.with_class_func("redis.asyncio.client.Pipeline.execute").use(
        async_pipeline_wrapper
    )
    transformer.with_class_func(
        "redis.asyncio.client.Pipeline.immediate_execute_command"
    ).use(async_standard_wrapper)

    if transformer.matches_version_spec("<4.3.2"):  # asyncio cluster support
        return

    transformer.with_class_func(
        "redis.asyncio.cluster.RedisCluster.__init__"
    ).use(cluster_init_wrapper)
    transformer.with_class_func(
        "redis.asyncio.cluster.RedisCluster.pipeline"
    ).use(cluster_pipeline_func_wrapper)
    transformer.with_class_func(
        "redis.asyncio.cluster.RedisCluster.execute_command"
    ).use(async_standard_wrapper)
    transformer.with_class_func(
        "redis.asyncio.cluster.ClusterPipeline.execute"
    ).use(async_pipeline_wrapper)

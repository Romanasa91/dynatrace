from types import ModuleType

from dynatrace.otel.hooks.instrumentation import BaseInstrumentationHook


class BotocoreInstrumentationHook(BaseInstrumentationHook):
    library_name = "botocore"
    version_specifiers = ""

    def _get_library_version(self, mod: ModuleType) -> str:
        return ""

    def _instrument(self, mod: ModuleType):
        from dynatrace.otel.sensors.awslambda.outgoing import (  # pylint: disable=import-outside-toplevel
            OutgoingAwsLambdaInstrumentor,
        )

        OutgoingAwsLambdaInstrumentor().instrument()

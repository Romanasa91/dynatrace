import logging

logger = logging.getLogger("dynatrace.inject.awslambda")

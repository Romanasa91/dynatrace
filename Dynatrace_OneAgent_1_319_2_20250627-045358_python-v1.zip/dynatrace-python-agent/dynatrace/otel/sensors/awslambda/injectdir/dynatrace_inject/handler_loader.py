import importlib
import sys
from typing import Callable

from dynatrace_inject import (  # pylint:disable=import-error,no-name-in-module
    log,
)

logger = log.logger


class HandlerLoadError(Exception):
    pass


def load_handler(handler: str) -> Callable:
    try:
        (modname, fname) = handler.rsplit(".", 1)
    except (AttributeError, ValueError) as ex:
        fault = HandlerLoadError(f"Bad handler '{handler}': {str(ex)}")
        return _make_fault_handler(fault)

    try:
        if modname.split(".")[0] in sys.builtin_module_names:
            fault = HandlerLoadError(
                f"Cannot use built-in module {modname} as a handler module"
            )
            return _make_fault_handler(fault)
        mod = importlib.import_module(modname.replace("/", "."))
    except ImportError as ex:
        return _make_fault_handler(ex)
    except SyntaxError as ex:
        return _make_fault_handler(ex)

    try:
        return getattr(mod, fname)
    except AttributeError:
        fault = HandlerLoadError(
            f"Handler '{fname}' missing on module '{modname}'"
        )
        return _make_fault_handler(fault)


def _make_fault_handler(exception: Exception):
    # We log the exception potentially twice here because an
    # exception that was never thrown causes exc_info to do
    # nothing.
    logger.error(
        "Failed to load original function handler: %s",
        exception,
        exc_info=exception,
    )
    orig_traceback = exception.__traceback__

    def raising_handler(*args, **kwargs):
        raise exception.with_traceback(orig_traceback)

    return raising_handler

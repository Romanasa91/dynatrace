# This module holds our injected lambda function handler which is intended to be
# loaded by the AWS runtime instead of the original lambda function handler.
#
# ATTENTION: Be careful with global state in this module since it will be
# re-loaded when the AWS runtime loads the lambda handler function

import os
import sys
import typing

from dynatrace_inject import (  # pylint:disable=import-error,no-name-in-module
    handler_loader,
    injection_context,
    log,
)

logger = log.logger

_THIS_DIR = os.path.normcase(os.path.dirname(os.path.realpath(__file__)))
try:
    sys.path.remove(_THIS_DIR)
except ValueError:
    pass


def _inject_agent() -> typing.Tuple[typing.Callable, typing.Callable]:
    """Injects the Dynatrace agent with all its instrumentations/sensors.

    Returns the instrumented handler function and the original handler function.
    """
    agent = _load_and_setup_agent()

    handler_function = handler_loader.load_handler(  # pylint:disable=no-member
        injection_context.ORIG_HANDLER_FUNCTION_NAME
    )

    if agent is None:
        return handler_function, handler_function

    instrumented_handler = _load_and_setup_lambda_sensor(
        agent, handler_function
    )
    return instrumented_handler, handler_function


def _load_and_setup_agent():
    try:
        # pylint:disable=import-outside-toplevel
        from dynatrace.otel.sitedir import sitecustomize

        # start with suppressed tracing, incoming lambda sensor will re-enable
        # it when the lambda function gets invoked. This is to ensure that the
        # incoming lambda span is the root span as other spans could be potentially
        # created in the module scope of the lambda handler.
        return sitecustomize.setup_agent(
            enable_global_tracing_suppression=True,
        )
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to inject Dynatrace agent", exc_info=ex)

        return None
    finally:
        logger.info(
            "AWS Lambda runtime .... %s (%s MB)",
            os.environ.get("AWS_EXECUTION_ENV"),
            os.environ.get("AWS_LAMBDA_FUNCTION_MEMORY_SIZE"),
        )


def _load_and_setup_lambda_sensor(
    agent, handler_function: typing.Callable
) -> typing.Callable:
    instrumented_handler = None
    try:
        # pylint:disable=import-outside-toplevel
        from dynatrace.otel.sensors.awslambda import incoming

        # incoming AWS lambda sensor is not loaded/instrumented together with
        # the agent since it requires agent and handler function.
        # explicitly setup the sensor here
        instrumentor = incoming.IncomingAwsLambdaInstrumentor()

        instrumented_handler = instrumentor.instrument(
            dt_agent=agent, handler_function=handler_function
        )
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning(
            "Failed to setup incoming AWS lambda sensor", exc_info=ex
        )
    return instrumented_handler or handler_function


sys.path.append(
    sys.modules["dynatrace_sitecustomize"].get_source_root(_THIS_DIR)
)
# Since this module is imported by the AWS runtime when it loads the handler
# function everything should be setup by now. So let's inject the agent.
# 'handler' is the function which will be called by the AWS runtime. Its name
# has to match the function name in 'injection_context.DT_HANDLER_FUNCTION_NAME'
handler, original_handler = _inject_agent()

# Holds the location with which the sitecustomize script will update the
# _HANDLER environment variable. The AWS runtime will then load this handler
DT_HANDLER_FUNCTION_NAME = "dynatrace_inject.lambda_handler.handler"

# Will hold the original content of the _HANDLER environment variable after
# _HANDLER was replaced with our handler function
ORIG_HANDLER_FUNCTION_NAME = None

"""Sets up the injection of the Dynatrace agent and its sensors.

The idea for injecting the agent is to update the environment variable pointing
to the handler function to a handler function which is in our control. This will
cause the AWS runtime to load our handler module + function were we then can
inject/setup the agent and call the original handler function.

The whole process happens as follows:
- when the python interpreter starts up it will load this sitecustomize script
  (given that the PYTHONPATH is set accordingly)
- this script will read and replace the environment variable pointing to the
  original handler function.
- the content of the environment variable for the original handler function will
  be stored as module global variable for loading the original handler function
  later when the agent is injected.
- when the AWS runtime starts up it will setup the python runtime (mostly
  sys.path) and load the handler function from the environment variable
  afterwards.
- by loading the handler function it will have to load/import the module in
  which the function is contained. Since we have replaced the handler environment
  variable accordingly the AWS runtime will load our handler module + function.
- When our handler module is imported it will as last step try to setup the
  agent and load the incoming AWS lambda sensor
- the sensor will then load the original handler function and wrap it to create
  a span on invocation. Besides the handler function further functions of the
  AWS runtime are wrapped and replaced, e.g. for ending a span, posting the
  result or error of the lambda function
- when the AWS runtime calls the lambda function handler, it will first call
  our handler function, which will then delegate the call further to the wrapped
  handler function to produce spans.
  In case the agent/sensor failed to inject our handler function will try load
  and use the original handler function.

Since we are injecting the agent when the handler function is loaded we should
not have the problem that the sys.path is not yet setup by the AWS runtime.
Furthermore, having sys.path setup correctly is essential since the agent uses
pkg_resources to load required sensors via the entry_points mechanism.
Importing pkg_resources the first time seems to freeze the packages known to
the python interpreter. So injecting the agent to early would cause import
errors for packages and modules which are actually existing.
"""

import logging
import os
import sys
import typing


def run_sitecustomize():
    this_dir = None
    try_next = False
    try:
        this_dir = _get_current_dir()
        sys.modules["dynatrace_sitecustomize"] = sys.modules.pop(__name__)
        if os.path.normcase(os.path.realpath(sys.path[0])) == this_dir:
            del sys.path[0]
            try_next = True

        _substitute_handler_env_var()
    except Exception as ex:  # pylint:disable=broad-except
        logger = logging.getLogger("dynatrace.inject.awslambda")
        logger.warning(
            "Failed substitute handler environment var", exc_info=ex
        )
    finally:
        cleanup_pythonpath(this_dir)

    if try_next:
        __import__("sitecustomize")


def _substitute_handler_env_var():
    _adapt_sys_path()

    # pylint:disable=import-outside-toplevel,import-error,no-name-in-module
    from dynatrace_inject import injection_context

    handler_func_key = "_HANDLER"
    orig_handler_func_name = os.environ.get(handler_func_key)
    if not orig_handler_func_name:
        raise ValueError("Lambda handler function not found.")

    injection_context.ORIG_HANDLER_FUNCTION_NAME = orig_handler_func_name
    os.environ[handler_func_key] = injection_context.DT_HANDLER_FUNCTION_NAME


def _adapt_sys_path():
    """This puts dynatrace_inject on the path."""
    this_dir = _get_current_dir()
    source_root_dir = get_source_root(this_dir)
    inject_root_dir = os.path.join(
        source_root_dir,
        "dynatrace",
        "otel",
        "sensors",
        "awslambda",
        "injectdir",
    )
    sys.path.append(inject_root_dir)


def _get_current_dir():
    return os.path.normcase(os.path.dirname(os.path.realpath(__file__)))


def get_source_root(this_dir: str) -> typing.Optional[str]:
    current_dir = this_dir
    while True:
        head, tail = os.path.split(current_dir)
        if head == current_dir:
            return None
        if tail == "dynatrace":
            return head
        current_dir = head


def cleanup_pythonpath(this_dir: typing.Optional[str]):
    """Removes this directory from the PYTHONPATH env variable and unsets it if
    it is empty.

    The AWS does not add the source locations of the layers (/opt/python/...) to
    sys.path if the PYTHONPATH env variable is set.
    """
    if this_dir is None:
        return
    python_path = os.environ.get("PYTHONPATH")
    if python_path is None:
        return
    if not python_path:
        del os.environ["PYTHONPATH"]
        return

    updated_paths = []
    paths = python_path.split(os.pathsep)
    for path in paths:
        if not this_dir == os.path.normcase(os.path.realpath(path)):
            updated_paths.append(path)
    if not updated_paths:
        os.environ.pop("PYTHONPATH")
    else:
        os.environ["PYTHONPATH"] = os.pathsep.join(updated_paths)


if __name__ == "sitecustomize":
    run_sitecustomize()

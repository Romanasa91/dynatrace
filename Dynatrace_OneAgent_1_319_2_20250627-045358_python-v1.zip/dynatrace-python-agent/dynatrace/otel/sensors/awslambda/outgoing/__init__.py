import importlib
import re
import sys
from typing import Any, Collection, Dict, List, Optional, Tuple

import wrapt

import dynatrace.odin.semconv.v1 as semconv
from dynatrace.opentelemetry.tracing._logging.loggers import lambda_sdk_logger
from dynatrace.opentelemetry.tracing._propagator.textmap import (
    X_DYNATRACE_HEADER_KEY,
)
from dynatrace.opentelemetry.tracing._util.context import suppressed_tracing
from dynatrace.opentelemetry.tracing._util.exceptions import record_exception
from dynatrace.otel.sensors.awslambda.common.client_context import (
    ClientContextManipulator,
)
from dynatraceotel.instrumentation.instrumentor import BaseInstrumentor
from dynatraceotel.instrumentation.utils import unwrap
from dynatraceotel.propagate import inject
from dynatraceotel.trace import SpanKind, get_tracer, use_span
from dynatraceotel.trace.span import Span

logger = lambda_sdk_logger

_INSTRUMENTATION_LIB_NAME = "dt.agent.python.awslambda-out"

BOTO_MODULE = "botocore.client"
BOTO_CLIENT_CLASS = "BaseClient"
INSTRUMENTED_FUNC = "_make_api_call"

# botocore.client.BaseClient attribute paths
CLOUD_REGION = ("meta", "region_name")
SERVICE_NAME = ("_service_model", "service_name")
API_VERSION = ("_service_model", "api_version")

# keys in params dictionary
FUNCTION_NAME_KEY = "FunctionName"
INVOCATION_TYPE_KEY = "InvocationType"
CLIENT_CONTEXT_KEY = "ClientContext"

SUPPORTED_API_VERSIONS = {"2015-03-31"}

# https://docs.aws.amazon.com/lambda/latest/dg/API_Invoke.html#API_Invoke_RequestParameters
ARN_LAMBDA_PATTERN = re.compile(
    "(?:arn:(?:aws[a-zA-Z-]*)?:lambda:)?"
    "(?:[a-z]{2}(?:-gov)?-[a-z]+-\\d{1}:)?(?:\\d{12}:)?"
    "(?:function:)?([a-zA-Z0-9-_\\.]+)(?::(?:\\$LATEST|[a-zA-Z0-9-_]+))?"
)


class OutgoingAwsLambdaInstrumentor(BaseInstrumentor):
    def instrumentation_dependencies(self) -> Collection[str]:
        return ()

    def _instrument(self, **_):
        # pylint: disable=attribute-defined-outside-init
        self.tracer = get_tracer(_INSTRUMENTATION_LIB_NAME, "")
        _instrument_botocore(self)

    def _uninstrument(self, **_):
        boto_module = importlib.import_module(BOTO_MODULE)
        boto_client = getattr(boto_module, BOTO_CLIENT_CLASS, None)
        if boto_client:
            unwrap(boto_client, INSTRUMENTED_FUNC)


def _instrument_botocore(instrumentor: OutgoingAwsLambdaInstrumentor):
    def instrumented_make_api_call(wrapped, instance, args, kwargs):
        operation, params = _extract_params(args)
        span = _create_span(instrumentor, instance, operation, params)
        if span is None:
            return wrapped(*args, **kwargs)

        with use_span(span, end_on_exit=True, record_exception=False):
            orig_client_context = _inject_tag(params)
            result = None

            try:
                # since this is the outgoing span, suppress further spans
                # (e.g. HTTP span by urllib3 internally used by botocore)
                with suppressed_tracing():
                    result = wrapped(*args, **kwargs)
            finally:
                exception = sys.exc_info()[1]
                record_exception(span, exception)
                _apply_result_to(span, result, exception)
                _restore_client_context(params, orig_client_context)
            return result

    wrapt.wrap_function_wrapper(
        BOTO_MODULE,
        ".".join((BOTO_CLIENT_CLASS, INSTRUMENTED_FUNC)),
        instrumented_make_api_call,
    )


def _extract_params(
    args: List[Any],
) -> Tuple[Optional[str], Optional[Dict[str, Any]]]:
    try:
        return args[0], args[1]
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to extract parameters", exc_info=ex)
    return None, None


def _create_span(
    instrumentor: OutgoingAwsLambdaInstrumentor,
    boto_client,
    operation: str,
    params: Dict[str, Any],
):
    try:
        if not _is_call_relevant(boto_client, operation, params):
            return None

        function_name = parse_function_name(params)
        attributes = {
            semconv.FAAS_INVOKED_PROVIDER: "aws",
            semconv.FAAS_INVOKED_NAME: function_name,
            semconv.FAAS_INVOKED_REGION: _resolve_attr(
                boto_client, CLOUD_REGION
            ),
        }
        logger.debug("Starting span %s", attributes)

        return instrumentor.tracer.start_span(
            "AWS-SDK call to " + function_name,
            kind=SpanKind.CLIENT,
            attributes=attributes,
            record_exception=False,  # handled by ourself
        )
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to create span", exc_info=ex)
    return None


def _inject_tag(params: Dict[str, Any]):
    carrier = {}
    inject(carrier)
    tag = carrier.get(X_DYNATRACE_HEADER_KEY)

    logger.debug("Using tag: %s", tag)

    orig_client_context = params.get(CLIENT_CONTEXT_KEY)
    if tag:
        manipulator = ClientContextManipulator.from_base64(orig_client_context)
        manipulator.set_tag(tag)
        params[CLIENT_CONTEXT_KEY] = manipulator.to_base64()
    return orig_client_context


def _apply_result_to(
    span: Span, result: Dict[str, Any], exception: Optional[BaseException]
):
    try:
        # botocore.exceptions.ClientError.response holds the result in case of
        # an exception
        result = result if result is not None else exception.response
        response_meta = result["ResponseMetadata"]  # type:Dict[str, Any]
        span.set_attribute(
            semconv.DT_FAAS_AWS_X_AMZN_REQUEST_ID,
            response_meta.get("RequestId"),
        )

        headers = response_meta["HTTPHeaders"]  # type:Dict[str, Any]
        span.set_attribute(
            semconv.DT_FAAS_AWS_X_AMZN_TRACE_ID, headers.get("x-amzn-trace-id")
        )
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to apply result to span", exc_info=ex)


def _restore_client_context(params: Dict[str, Any], orig_client_context: str):
    try:
        if orig_client_context is not None:
            params[CLIENT_CONTEXT_KEY] = orig_client_context
        else:
            params.pop(CLIENT_CONTEXT_KEY, None)
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to restore client context", exc_info=ex)


def _is_call_relevant(boto_client, operation: str, params: Dict[str, Any]):
    try:
        if operation.lower() != "invoke":
            logger.debug("Ignoring operation %s", operation)
            return False

        service_name = _resolve_attr(boto_client, SERVICE_NAME)
        if service_name != "lambda":
            logger.debug("Ignoring service %s", service_name)
            return False

        invocation_type = params.get(INVOCATION_TYPE_KEY)
        if invocation_type == "DryRun":
            logger.debug("Ignoring invocation type %s", invocation_type)
            return False

        api_version = _resolve_attr(boto_client, API_VERSION)
        if api_version not in SUPPORTED_API_VERSIONS:
            logger.debug("Ignoring not supported API version %s", api_version)
            return False
        logger.debug(
            "Calling _make_api_call: api=%s, svc=%s, op=%s, type=%s",
            api_version,
            service_name,
            operation,
            invocation_type,
        )
        return True
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed when checking call relevance", exc_info=ex)
    return False


def parse_function_name(kwargs):
    """Parse the function name from the given arguments containing either the
    ARN or the function name itself.

    The function name may be in the format of: (see: https://docs.aws.amazon.com/lambda/latest/dg/API_Invoke.html#API_Invoke_RequestParameters)
        - function name only: 'my-function'
        - function ARN: arn:aws:lambda<region>:<account-id>:function:<function-name>
        - partal ARN: <account-id>:function:<function-name> or <account-id>:<function-name>

    ARN syntax see: https://docs.aws.amazon.com/general/latest/gr/aws-arns-and-namespaces.html?shortFooter=true#arn-syntax-lambda
        - arn:aws:lambda:<region>:<account-id>:function:<function-name>
        - arn:aws:lambda:<region>:<account-id>:function:<function-name>:<alias-name>
        - arn:aws:lambda:<region>:<account-id>:function:<function-name>:<version>
        - arn:aws:lambda:<region>:<account-id>:<event-source-mappings>:<event-source-mapping-id>
    """
    function_name_or_arn = kwargs.get(FUNCTION_NAME_KEY)  # type: str
    matches = ARN_LAMBDA_PATTERN.match(function_name_or_arn)
    function_name = matches.group(1)
    if function_name is None:
        logger.debug("Malformed function name '%s'", function_name_or_arn)
        return function_name_or_arn
    if function_name != function_name_or_arn:
        logger.debug(
            "Parsed '%s' from '%s'", function_name, function_name_or_arn
        )
    return function_name


def _resolve_attr(instance: Any, attr_path: Tuple[str, ...], default=None):
    for attr in attr_path:
        try:
            instance = getattr(instance, attr)
        except AttributeError:
            return default
    return instance

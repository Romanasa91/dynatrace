import logging

logger = logging.getLogger("dynatrace.sensors.awslambda")

import base64
import json
import logging
from typing import Any, Dict, Optional

from dynatrace.otel.sensors.awslambda.common.log import logger
from dynatrace.otel.sensors.awslambda.common.types import LambdaContext

# the tag is to be transported in ClientContext.Custom
DYNATRACE_LINK_KEY = "dynatrace-link"
CLIENT_CONTEXT_ENCODING = "utf-8"
# the encoded client context is limited in size
# https://docs.aws.amazon.com/lambda/latest/dg/API_Invoke.html#API_Invoke_RequestSyntax
CLIENT_CONTEXT_MAX_LEN = 3583


class ClientContextManipulator:
    def __init__(
        self,
        orig_encoded_ctx: Optional[str],
        decoded_ctx: Optional[Dict[str, Any]],
    ):
        self.orig_encoded_ctx = orig_encoded_ctx
        self.decoded_ctx = decoded_ctx

    @staticmethod
    def from_client_context(decoded_ctx: Optional[Dict[str, Any]]):
        return ClientContextManipulator(None, decoded_ctx)

    @staticmethod
    def from_base64(orig_encoded_ctx: Optional[str]):
        decoded_ctx = ClientContextManipulator._decode(orig_encoded_ctx)
        return ClientContextManipulator(orig_encoded_ctx, decoded_ctx)

    @staticmethod
    def _decode(orig_encoded_ctx: str):
        if not orig_encoded_ctx:
            return {}
        try:
            decoded_bytes = base64.b64decode(
                orig_encoded_ctx.encode(CLIENT_CONTEXT_ENCODING)
            )
            decoded_str = decoded_bytes.decode(CLIENT_CONTEXT_ENCODING)
            return json.loads(decoded_str)
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning("Failed to parse ClientContext", exc_info=ex)
        return None

    def to_base64(self) -> Optional[str]:
        if self.decoded_ctx is None:
            return self.orig_encoded_ctx

        try:
            decoded_json = json.dumps(self.decoded_ctx)
            decoded_bytes = decoded_json.encode(CLIENT_CONTEXT_ENCODING)
            encoded_bytes = base64.b64encode(decoded_bytes)
            if len(encoded_bytes) > CLIENT_CONTEXT_MAX_LEN:
                logger.warning("Max length limit exceeded")
                return self.orig_encoded_ctx
            return encoded_bytes.decode(CLIENT_CONTEXT_ENCODING)
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning("Failed to re-encode ClientContext", exc_info=ex)
        return None

    def set_tag(self, tag: str):
        if self.decoded_ctx is None:
            return
        try:
            custom = self.get_custom()
            if custom is None:
                custom = {}
                self.decoded_ctx["custom"] = custom
            if isinstance(custom, dict):
                custom[DYNATRACE_LINK_KEY] = tag
            elif logger.isEnabledFor(logging.DEBUG):
                logger.debug(
                    "Tag %s not set. Custom (%s) is not of type dict",
                    tag,
                    type(custom),
                )
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning("Failed to set tag", exc_info=ex)

    def get_tag(self) -> Optional[str]:
        custom = self.get_custom()
        if not isinstance(custom, Dict):
            return None
        return custom.get(DYNATRACE_LINK_KEY)

    @staticmethod
    def get_tag_from_context(context: LambdaContext) -> Optional[str]:
        if not context:
            return None
        client_context = getattr(context, "client_context", None)
        if not client_context:
            return None
        custom = getattr(client_context, "custom", None)
        if not isinstance(custom, dict):
            return None
        return custom.get(DYNATRACE_LINK_KEY)

    def get_custom(self) -> Optional[Dict[str, Any]]:
        """Returns ClientContext.custom (preferred) or ClientContext.Custom or
        None if it it does not exist.
        """
        if self.decoded_ctx is None:
            return None
        custom = self.decoded_ctx.get("custom")
        if custom is not None:
            return custom
        return self.decoded_ctx.get("Custom")

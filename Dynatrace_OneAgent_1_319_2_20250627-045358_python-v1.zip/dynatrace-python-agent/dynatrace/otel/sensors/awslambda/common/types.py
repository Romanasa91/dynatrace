import typing

LambdaDict = typing.Dict[str, typing.Any]

################################################################################
# Context related type definitions
# https://docs.aws.amazon.com/lambda/latest/dg/python-context.html
################################################################################


class LambdaCognitoIdentity:
    cognito_identity_id: str
    """The authenticated Amazon Cognito identity."""
    cognito_identity_pool_id: str
    """The Amazon Cognito identity pool that authorized the invocation."""


class LambdaClientContextAttributes:
    installation_id: str
    app_title: str
    app_version_name: str
    app_package_name: str


class LambdaClientContext:
    client: LambdaClientContextAttributes
    custom: LambdaDict
    """A dict of custom values set by the mobile client application."""
    env: LambdaDict
    """A dict of environment information provided by the AWS SDK."""


class LambdaContext:
    """Type definitions for AWS lambda context"""

    function_name: str
    """The name of the Lambda function."""
    function_version: str
    """The version of the function."""
    invoked_function_arn: str
    """The Amazon Resource Name (ARN) that's used to invoke the function.
    Indicates if the invoker specified a version number or alias.
    """
    memory_limit_in_mb: str
    """The amount of memory that's allocated for the function."""
    aws_request_id: str
    """The identifier of the invocation request."""
    log_group_name: str
    """The log group for the function."""
    log_stream_name: str
    """The log stream for the function instance."""
    identity: LambdaCognitoIdentity
    """(mobile apps) Information about the Amazon Cognito identity that
    authorized the request.
    """
    client_context: LambdaClientContext
    """(mobile apps) Client context that's provided to Lambda by the client
    application.
    """

    @staticmethod
    def get_remaining_time_in_millis() -> int:
        """Returns the number of milliseconds left before the execution times
        out.
        """


################################################################################
# Event related type definitions
# https://docs.aws.amazon.com/lambda/latest/dg/python-handler.html
################################################################################

LambdaEvent = typing.Union[typing.Mapping, typing.List, str, int, float, None]

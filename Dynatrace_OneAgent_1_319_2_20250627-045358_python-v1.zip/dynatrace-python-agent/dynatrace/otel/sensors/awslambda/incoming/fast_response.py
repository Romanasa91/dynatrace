import os
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection
from typing import Optional

from dynatrace.opentelemetry.tracing._logging.loggers import lambda_logger
from dynatrace.otel.agent import DynatraceAgent

logger = lambda_logger

_API_EXTENSION_REGISTER = "/2020-01-01/extension/register"
_API_EXTENSION_NEXT = "/2020-01-01/extension/event/next"
_LAMBDA_RUNTIME_API_ENV_VAR = "AWS_LAMBDA_RUNTIME_API"
_EXTENSION_NAME = "DynatraceOdinFastResponseExtension"


class FastResponseExtension:
    def __init__(self, agent: DynatraceAgent):
        self._agent = agent
        self._base_url = os.environ.get(_LAMBDA_RUNTIME_API_ENV_VAR)
        self._extension_id = None
        self._handler_connection: Optional[HTTPConnection] = None
        self._extension_connection: Optional[HTTPConnection] = None
        self._executor: Optional[HTTPConnection] = None

    def is_active(self):
        return self._extension_id is not None

    def register_and_signal_next(self):
        if self.is_active():
            logger.warning(
                "%s already registered. id=%s",
                _EXTENSION_NAME,
                self._extension_id,
            )
            return

        if not self._base_url:
            logger.debug(
                "%s not set, skipping lambda extension registration.",
                _LAMBDA_RUNTIME_API_ENV_VAR,
            )
            return

        if not self._agent.config.enable_lambda_extension_registration:
            logger.debug("Extension registration not activated.")
            return

        self._handler_connection = HTTPConnection(self._base_url)
        self._extension_connection = HTTPConnection(self._base_url)
        self._executor = ThreadPoolExecutor(1, "dt-lambda-extension")

        try:
            self._executor.submit(lambda: None)  # pre-start the thread
            self._extension_id = self._try_register_extension()
            self.signal_next()
        finally:
            if self._extension_id is None:
                self._executor.shutdown()

    def _try_register_extension(self):
        logger.debug(
            "Trying to register %s at %s",
            _EXTENSION_NAME,
            _API_EXTENSION_REGISTER,
        )

        headers = {
            "Content-Type": "application/json",
            "Lambda-Extension-Name": _EXTENSION_NAME,
        }

        connection = self._extension_connection
        connection.request(
            "POST",
            _API_EXTENSION_REGISTER,
            headers=headers,
            body='{"events": ["INVOKE"]}',
        )
        response = connection.getresponse()
        response.read()  # drain connection

        if response.status < 200 or response.status > 299:
            logger.warning(
                "Lambda API %s returned with HTTP %s",
                _API_EXTENSION_REGISTER,
                response.status,
            )
            return None

        extension_id = response.headers.get("Lambda-Extension-Identifier")
        if extension_id is None:
            logger.warning(
                "Lambda API %s returned empty extension ID",
                _API_EXTENSION_REGISTER,
            )
        else:
            logger.debug(
                "Registered extension %s with ID %s",
                _EXTENSION_NAME,
                extension_id,
            )
        return extension_id

    def _flush_spans(self):
        try:
            flushed = self._agent.tracer_provider.force_flush()
            if flushed:
                logger.debug("Finished flushing spans")
            else:
                logger.warning("Flushing spans timed out.")
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning("Failed to flush spans", exc_info=ex)

    def _request_extension_next(self):
        logger.debug(
            "%s requesting %s: id=%s",
            _EXTENSION_NAME,
            _API_EXTENSION_NEXT,
            self._extension_id,
        )

        try:
            headers = {"Lambda-Extension-Identifier": self._extension_id}
            connection = self._extension_connection
            connection.request("GET", _API_EXTENSION_NEXT, headers=headers)
            response = connection.getresponse()
            response.read()  # drain connection

            logger.debug(
                "%s %s returned with HTTP %s",
                _EXTENSION_NAME,
                _API_EXTENSION_NEXT,
                response.status,
            )
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning(
                "Exception while requesting %s",
                _API_EXTENSION_NEXT,
                exc_info=ex,
            )

    def _flush_and_request_extension_next(self):
        self._flush_spans()
        self._request_extension_next()

    def flush_spans(self):
        if not self.is_active():
            self._flush_spans()
        else:
            self._executor.submit(self._flush_and_request_extension_next)

    def signal_next(self):
        if self.is_active():
            self._executor.submit(self._request_extension_next)

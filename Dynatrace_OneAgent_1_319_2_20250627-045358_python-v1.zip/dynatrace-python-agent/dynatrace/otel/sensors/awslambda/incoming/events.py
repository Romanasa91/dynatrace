import abc
import inspect
import json
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple, Union

import dynatrace.odin.semconv.v1 as semconv
from dynatrace.opentelemetry.tracing._config.settings import DtConfig
from dynatrace.opentelemetry.tracing._logging.loggers import lambda_logger
from dynatrace.opentelemetry.tracing._propagator.textmap import (
    X_DYNATRACE_HEADER_KEY,
)
from dynatrace.opentelemetry.tracing._util.http import capture_headers
from dynatrace.otel.sensors.awslambda.common.client_context import (
    ClientContextManipulator,
)
from dynatrace.otel.sensors.awslambda.common.types import (
    LambdaContext,
    LambdaEvent,
)
from dynatraceotel.context import Context
from dynatraceotel.propagate import extract
from dynatraceotel.propagators.textmap import CarrierValT, DefaultGetter
from dynatraceotel.trace import Link, SpanKind
from dynatraceotel.trace.propagation import get_current_span
from dynatraceotel.trace.span import Span
from dynatraceotel.util import types

logger = lambda_logger

AttributePath = Tuple[Union[str, int], ...]
AttributeMapping = Dict[str, types.AttributeValue]


def _get_attribute(
    attribute_path: AttributePath, event: Mapping[str, Any]
) -> Optional[Any]:
    current_scope = event
    for attribute in attribute_path:
        try:
            current_scope = current_scope[attribute]
        except (TypeError, KeyError, IndexError):
            return None
    return current_scope


class CarrierGetter(DefaultGetter):
    def __init__(self, lower_case_keys=False):
        super().__init__()
        self._lower_case_keys = lower_case_keys

    def get(self, carrier: Dict[str, CarrierValT], key: str) -> List[str]:
        key = key.lower() if self._lower_case_keys else key
        return super().get(carrier, key)


CARRIER_DICT_GETTER = CarrierGetter()
CARRIER_DICT_GETTER_LOWER_CASE = CarrierGetter(lower_case_keys=True)


def _to_lower_case_headers(headers: Optional[Dict]) -> Optional[Dict]:
    if not headers:
        return headers
    return {key.lower(): value for key, value in headers.items()}


class EventMapperArgs:
    def __init__(
        self, config: DtConfig, event: LambdaEvent, context: LambdaContext
    ):
        self.config = config
        self.event = event
        self.context = context
        self.event_source = self._determine_event_source(event)
        self.is_mapping_event = isinstance(event, Mapping)

    @staticmethod
    def _determine_event_source(event: LambdaEvent) -> Optional[str]:
        for source_attr in ("eventSource", "EventSource"):
            event_source_path = ("Records", -1, source_attr)
            event_source = _get_attribute(event_source_path, event)
            if isinstance(event_source, str):
                return event_source.lower()
        return None


class AwsEventAttributeMapper(abc.ABC):
    def __init__(self, args: EventMapperArgs):
        self._config = args.config
        self._event = args.event
        self._context = args.context

    def extract_parent(self, ctx: Context) -> Tuple[Context, Sequence[Link]]:
        # pylint: disable=no-self-use
        return ctx, ()

    @abc.abstractmethod
    def apply_to(self, attrs: AttributeMapping):
        pass

    def apply_result_to(self, result: Dict, span: Span):
        pass

    @classmethod
    @abc.abstractmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        pass

    @classmethod
    def can_handle_event_type(cls, args: EventMapperArgs) -> bool:
        return args.is_mapping_event

    @property
    def span_kind(self):
        return SpanKind.SERVER


################################################################################
# Default mapper in case no other mapper matched the event
################################################################################
class DefaultEventAttributeMapper(AwsEventAttributeMapper):
    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return False

    @classmethod
    def can_handle_event_type(cls, args: EventMapperArgs) -> bool:
        return False


################################################################################
# API Gateway event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/services-apigateway.html
# https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html
################################################################################
class ApiGatewayProxyAttributeMapper(AwsEventAttributeMapper):
    # implement in subclass
    VERSION_PATH: AttributePath = ("version",)
    REQUEST_CONTEXT_STAGE: AttributePath = ("requestContext", "stage")
    HTTP_HEADERS_PATH: AttributePath = ("headers",)
    HTTP_METHOD_PATH: AttributePath
    HTTP_METHOD_FALLBACK_PATH: AttributePath = None
    HTTP_TARGET_PATH: AttributePath
    HTTP_TARGET_FALLBACK_PATH: AttributePath = None

    MANDATORY_HEADERS = {"host"}

    def __init__(
        self,
        args: EventMapperArgs,
        headers: Dict,
        multi_value_headers: Optional[Dict],
    ):
        super().__init__(args)
        self._headers = headers
        self._multi_value_headers = multi_value_headers

    @classmethod
    def version(cls, event: Mapping[str, Any]) -> Optional[str]:
        return _get_attribute(cls.VERSION_PATH, event)

    @classmethod
    def http_method(cls, event: LambdaEvent) -> str:
        return _get_attribute(cls.HTTP_METHOD_PATH, event) or (
            _get_attribute(cls.HTTP_METHOD_FALLBACK_PATH, event)
            if cls.HTTP_METHOD_FALLBACK_PATH
            else None
        )

    @classmethod
    def http_target(cls, event: LambdaEvent) -> str:
        return _get_attribute(cls.HTTP_TARGET_PATH, event) or (
            _get_attribute(cls.HTTP_TARGET_FALLBACK_PATH, event)
            if cls.HTTP_TARGET_FALLBACK_PATH
            else None
        )

    @classmethod
    def stage(cls, event: LambdaEvent):
        return _get_attribute(cls.REQUEST_CONTEXT_STAGE, event)

    @classmethod
    @abc.abstractmethod
    def query_string(cls, event: LambdaEvent) -> Optional[str]:
        pass

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        event = args.event

        if not cls.matches_version(cls.version(event)):
            return False
        return bool(
            cls.http_method(event)
            and _get_attribute(cls.HTTP_HEADERS_PATH, event)
            and cls.stage(event)
        )

    @staticmethod
    @abc.abstractmethod
    def matches_version(version: Optional[str]) -> bool:
        pass

    def extract_parent(self, ctx: Context) -> Tuple[Context, Sequence[Link]]:
        if not self._headers:
            return ctx, ()

        parent_context = extract(
            self._headers, context=ctx, getter=CARRIER_DICT_GETTER_LOWER_CASE
        )
        return parent_context, ()

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.HTTP.value

        target = self.http_target(self._event)
        if self._log_missing_mandatory_attrs(target):
            return

        query_string = self.query_string(self._event)
        if query_string:
            target = f"{target}?{query_string}"

        attrs[semconv.HTTP_METHOD] = self.http_method(self._event)
        attrs[semconv.HTTP_TARGET] = target
        capture_headers(attrs, self._get_header_value, self._config)

    def _log_missing_mandatory_attrs(self, target: Optional[str]) -> bool:
        missing_attributes = []
        if not target:
            missing_target = ".".join(self.HTTP_TARGET_PATH)
            if self.HTTP_TARGET_FALLBACK_PATH:
                missing_target = f"{missing_target} or {'.'.join(self.HTTP_TARGET_FALLBACK_PATH)}"
            missing_attributes.append(missing_target)

        for header_key in self.MANDATORY_HEADERS:
            if not self._get_header_value(header_key):
                missing_attributes.append(
                    ".".join(self.HTTP_HEADERS_PATH + (header_key,))
                )

        if missing_attributes:
            logger.warning(
                "Detected HTTP event but missing relevant attributes: '%s'. "
                "They might not be mapped in the Lambda non-proxy integration"
                " mapping template. Please review your configuration.",
                missing_attributes,
            )
            return True
        return False

    def _get_header_value(self, key: str) -> Optional[str]:
        value = self._headers.get(key) if self._headers is not None else None
        if value is not None:
            return value

        if self._multi_value_headers:
            multi_values = self._multi_value_headers.get(key)
            if multi_values is not None:
                value = ",".join(multi_values)
        return value


class ApiGatewayProxyAttributeMapperV1(ApiGatewayProxyAttributeMapper):
    HTTP_METHOD_PATH = ("requestMethod", "httpMethod")
    HTTP_METHOD_FALLBACK_PATH = ("httpMethod",)
    HTTP_TARGET_PATH = ("requestContext", "path")
    HTTP_TARGET_FALLBACK_PATH = ("path",)
    MULTI_VALUE_HEADER_PATH = ("multiValueHeaders",)
    QUERY_STRING_MULTI_PATH = ("multiValueQueryStringParameters",)
    QUERY_STRING_SINGLE_PATH = ("queryStringParameters",)

    def __init__(self, args: EventMapperArgs):
        headers = _to_lower_case_headers(
            _get_attribute(self.HTTP_HEADERS_PATH, args.event)
        )
        multi_value_headers = _to_lower_case_headers(
            _get_attribute(self.MULTI_VALUE_HEADER_PATH, args.event)
        )
        super().__init__(args, headers, multi_value_headers)

    @classmethod
    def query_string(cls, event: LambdaEvent) -> Optional[str]:
        query_params = _get_attribute(cls.QUERY_STRING_MULTI_PATH, event)
        if query_params:
            try:
                return "&".join(
                    f"{key}={value}"
                    for key, values in query_params.items()
                    if values is not None
                    for value in values
                    if value is not None
                )
            except Exception as ex:  # pylint: disable=broad-except
                logger.warning(
                    "Could not extract multi query params from '%s': %s - %s",
                    query_params,
                    type(ex).__name__,
                    ex,
                )

        query_params = _get_attribute(cls.QUERY_STRING_SINGLE_PATH, event)
        if query_params:
            try:
                return "&".join(
                    f"{key}={value.strip()}"
                    for key, values in query_params.items()
                    if values is not None
                    for value in values.split(",")
                )
            except Exception as ex:  # pylint: disable=broad-except
                logger.warning(
                    "Could not extract query params from '%s': %s - %s",
                    query_params,
                    type(ex).__name__,
                    ex,
                )

        return None

    def apply_result_to(self, result: Dict, span: Span):
        # https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html
        if not isinstance(result, Mapping):
            return
        status_code = result.get("statusCode")
        if isinstance(status_code, int):
            span.set_attribute(semconv.HTTP_STATUS_CODE, status_code)

    @staticmethod
    def matches_version(version: Optional[str]) -> bool:
        return not version or version == "1.0"


class ApiGatewayProxyAttributeMapperV2(ApiGatewayProxyAttributeMapper):
    HTTP_METHOD_PATH = ("requestContext", "http", "method")
    HTTP_TARGET_PATH = ("rawPath",)
    QUERY_STRING_PATH = ("rawQueryString",)

    def __init__(self, args: EventMapperArgs):
        headers = _get_attribute(self.HTTP_HEADERS_PATH, args.event)
        super().__init__(args, headers, None)

    @classmethod
    def query_string(cls, event: LambdaEvent) -> Optional[str]:
        return _get_attribute(cls.QUERY_STRING_PATH, event)

    def apply_result_to(self, result: Dict, span: Span):
        # https://docs.aws.amazon.com/apigateway/latest/developerguide/http-api-develop-integrations-lambda.html
        try:
            status_code = int(result.get("statusCode", 200))
        except Exception:  # pylint:disable=broad-except
            # V2 assumes 200 as default if status code is not present
            status_code = 200

        span.set_attribute(semconv.HTTP_STATUS_CODE, status_code)

    @staticmethod
    def matches_version(version: Optional[str]) -> bool:
        return version == "2.0"


################################################################################
# Elastic Load Balancing  event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/services-alb.html
################################################################################
class ElasticLoadBalancingAttributeMapper(AwsEventAttributeMapper):
    REQUEST_CONTEXT_ELB_PATH = ("requestContext", "elb")
    HTTP_METHOD_PATH = ("httpMethod",)

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return bool(
            _get_attribute(cls.REQUEST_CONTEXT_ELB_PATH, args.event)
            and _get_attribute(cls.HTTP_METHOD_PATH, args.event)
        )


################################################################################
# CloudFront event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/lambda-edge.html
################################################################################
class CloudFrontAttributeMapper(AwsEventAttributeMapper):
    RECORDS_CF_PATH = ("Records", 0, "cf")

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return bool(_get_attribute(cls.RECORDS_CF_PATH, args.event))


################################################################################
# DynamoDB stream event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/with-ddb.html
################################################################################
class DynamoDbAttributeMapper(AwsEventAttributeMapper):
    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return args.event_source == "aws:dynamodb"


################################################################################
# Kinesis Data Firehose event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/services-kinesisfirehose.html
################################################################################
class FirehoseAttributeMapper(AwsEventAttributeMapper):
    DELIVERY_STREAM_ARN_PATH = ("deliveryStreamArn",)
    KINESIS_RECORD_METADATA_PATH = ("records", 0, "kinesisRecordMetadata")

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return bool(
            _get_attribute(cls.DELIVERY_STREAM_ARN_PATH, args.event)
            and _get_attribute(cls.KINESIS_RECORD_METADATA_PATH, args.event)
        )


################################################################################
# Kinesis data stream event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/with-kinesis.html
################################################################################
class KinesisAttributeMapper(AwsEventAttributeMapper):
    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return args.event_source == "aws:kinesis"


################################################################################
# Simple Storage Service (S3) event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/with-s3.html
################################################################################
class S3AttributeMapper(AwsEventAttributeMapper):
    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return args.event_source == "aws:s3"


################################################################################
# Simple Email Service (SES) event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/services-ses.html
################################################################################
class SesAttributeMapper(AwsEventAttributeMapper):
    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return args.event_source == "aws:ses"


################################################################################
# Messaging (SQS and SNS)
################################################################################
class MessageAttributesGetter(DefaultGetter):
    def __init__(self, sub_key: str):
        self._sub_key = sub_key

    def get(
        self, carrier: Mapping[str, CarrierValT], key: str
    ) -> Optional[List[str]]:
        attr = carrier and carrier.get(key)
        if not isinstance(attr, Mapping):
            return None

        value = attr.get(self._sub_key)
        return [value] if value is not None else None


SNS_GETTER = MessageAttributesGetter("Value")
SQS_GETTER = MessageAttributesGetter("stringValue")


class MessagingMapper(AwsEventAttributeMapper, abc.ABC):
    RECORDS_PATH = ("Records",)
    # context propagation
    _PROPAGATION_GETTER: MessageAttributesGetter
    _RECORD_TO_CARRIER_PATH: AttributePath  # implemented in subclass
    # span attributes
    SOURCE_ARN_PATH: AttributePath
    MESSAGE_ID_PATH: AttributePath

    def __init__(self, args: EventMapperArgs):
        super().__init__(args)
        self._records = _get_attribute(self.RECORDS_PATH, args.event)
        self._last_record = self._records[-1]

    def extract_parent(self, ctx: Context) -> Tuple[Context, Sequence[Link]]:
        parent_ctx = self._extract_from_record(self._last_record, ctx)
        links = self._extract_links(parent_ctx)
        return parent_ctx, links

    def _extract_from_record(
        self, record: Dict[str, Any], ctx: Context
    ) -> Context:
        carrier = _get_attribute(self._RECORD_TO_CARRIER_PATH, record)
        if not carrier:
            return ctx

        return extract(carrier, context=ctx, getter=self._PROPAGATION_GETTER)

    def _extract_links(self, parent_ctx: Context) -> Sequence[Link]:
        links = []
        root_context = Context()

        for record in self._records[:-1]:
            link_ctx = self._extract_from_record(record, root_context)
            self._append_link_from_ctx(link_ctx, links)
        self._append_link_from_ctx(parent_ctx, links)

        return links

    @staticmethod
    def _append_link_from_ctx(context: Context, links: List[Link]):
        span_context = get_current_span(context).get_span_context()
        if span_context.is_valid:
            links.append(Link(span_context))

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.PUBSUB.value

        arn = _get_attribute(self.SOURCE_ARN_PATH, self._last_record)
        attrs[semconv.MESSAGING_DESTINATION] = self._dest_name_from_arn(arn)
        attrs[semconv.MESSAGING_URL] = arn
        attrs[semconv.MESSAGING_MESSAGE_ID] = _get_attribute(
            self.MESSAGE_ID_PATH, self._last_record
        )
        attrs[semconv.DT_MESSAGING_BATCH_SIZE] = len(self._records)

    @staticmethod
    def _dest_name_from_arn(arn: Optional[str]) -> Optional[str]:
        return arn.rsplit(":", 1)[-1] if isinstance(arn, str) else None

    @property
    def span_kind(self):
        return SpanKind.CONSUMER


# ------------------------------------------------------------------------------
# Simple Notification Service (SNS) event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/with-sns.html
# ------------------------------------------------------------------------------
class SnsAttributeMapper(MessagingMapper):
    _SNS_PATH = (
        "Records",
        -1,
        "Sns",
    )
    # context propagation
    _PROPAGATION_GETTER = SNS_GETTER
    _RECORD_TO_CARRIER_PATH = ("Sns", "MessageAttributes")
    # span attributes
    MESSAGE_ID_PATH = ("Sns", "MessageId")
    SOURCE_ARN_PATH = ("Sns", "TopicArn")

    def _extract_links(self, parent_ctx: Context) -> Sequence[Link]:
        return ()

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.MESSAGING_SYSTEM] = "aws.sns"
        attrs[semconv.MESSAGING_DESTINATION_KIND] = (
            semconv.MessagingDestinationKindValues.TOPIC.value
        )
        super().apply_to(attrs)

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return bool(
            args.event_source == "aws:sns"
            and _get_attribute(cls._SNS_PATH, args.event)
        )


# ------------------------------------------------------------------------------
# Simple Queue Service (SQS) event
# https://docs.aws.amazon.com/en_us/lambda/latest/dg/with-sqs.html
# ------------------------------------------------------------------------------
class SqsAttributeMapper(MessagingMapper):
    # context propagation
    _PROPAGATION_GETTER = SQS_GETTER
    _RECORD_TO_CARRIER_PATH = ("messageAttributes",)
    _MESSAGE_BODY_PATH = ("body",)
    _PAYLOAD_TO_CARRIER_PATH = ("MessageAttributes",)
    # span attributes
    SOURCE_ARN_PATH = ("eventSourceARN",)
    MESSAGE_ID_PATH = ("messageId",)

    def _extract_from_record(
        self, record: Dict[str, Any], ctx: Context
    ) -> Context:
        parent_ctx = super()._extract_from_record(record, ctx)
        if get_current_span(parent_ctx).get_span_context().is_valid:
            return parent_ctx

        return self._extract_from_payload(record, ctx)

    def _extract_from_payload(
        self, record: Dict[str, Any], ctx: Context
    ) -> Context:
        body = _get_attribute(self._MESSAGE_BODY_PATH, record)
        if (
            not isinstance(body, str)
            or not body.startswith("{")
            or '"MessageAttributes"' not in body
        ):
            return ctx

        try:
            parsed_body = json.loads(body)
        except json.JSONDecodeError:
            return ctx

        carrier = _get_attribute(self._PAYLOAD_TO_CARRIER_PATH, parsed_body)
        if not carrier:
            return ctx

        return extract(carrier, context=ctx, getter=SNS_GETTER)

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.MESSAGING_SYSTEM] = "aws.sqs"
        attrs[semconv.MESSAGING_DESTINATION_KIND] = (
            semconv.MessagingDestinationKindValues.QUEUE.value
        )
        super().apply_to(attrs)

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        return args.event_source == "aws:sqs"


################################################################################
# AWS Lambda (SDK) invoke
# https://docs.aws.amazon.com/lambda/latest/dg/API_Invoke.html
################################################################################
class AwsLambdaInvokeAttributeMapper(AwsEventAttributeMapper):
    def extract_parent(self, ctx: Context) -> Tuple[Context, Sequence[Link]]:
        tag = ClientContextManipulator.get_tag_from_context(self._context)
        if tag is None:
            return ctx, ()

        carrier = {X_DYNATRACE_HEADER_KEY: tag}
        return extract(carrier, context=ctx, getter=CARRIER_DICT_GETTER), ()

    def apply_to(self, attrs: AttributeMapping):
        attrs[semconv.FAAS_TRIGGER] = semconv.FaasTriggerValues.OTHER.value

    @classmethod
    def matches_event(cls, args: EventMapperArgs) -> bool:
        tag = ClientContextManipulator.get_tag_from_context(args.context)
        return tag is not None

    @classmethod
    def can_handle_event_type(cls, args: EventMapperArgs) -> bool:
        return True


################################################################################
# Event detection
################################################################################
_MAPPER_CLASSES = [
    cls
    for cls in globals().values()
    if inspect.isclass(cls)
    and issubclass(cls, AwsEventAttributeMapper)
    and not inspect.isabstract(cls)
    and cls not in (DefaultEventAttributeMapper,)
]


def get_event_mapper(
    config: DtConfig,
    event: LambdaEvent,
    context: LambdaContext,
) -> AwsEventAttributeMapper:
    args = EventMapperArgs(config, event, context)
    for mapper_class in _MAPPER_CLASSES:
        if not mapper_class.can_handle_event_type(args):
            continue
        if mapper_class.matches_event(args):
            logger.debug("Lambda event matched by %s ", mapper_class.__name__)
            return mapper_class(args)
    logger.info("Lambda event did not match any mapper, using default mapper")
    return DefaultEventAttributeMapper(args)

import sys
from typing import Callable, Collection, Optional

import wrapt

import dynatrace.odin.semconv.v1 as semconv
from dynatrace.opentelemetry.tracing._logging.loggers import (
    lambda_event_logger,
    lambda_logger,
)
from dynatrace.opentelemetry.tracing._util.exceptions import record_exception
from dynatrace.otel.agent import DynatraceAgent
from dynatrace.otel.sensors.awslambda.common.types import (
    LambdaContext,
    LambdaEvent,
)
from dynatrace.otel.sensors.awslambda.incoming import events, resources
from dynatrace.otel.sensors.awslambda.incoming.fast_response import (
    FastResponseExtension,
)
from dynatraceotel.context import Context
from dynatraceotel.instrumentation.instrumentor import BaseInstrumentor
from dynatraceotel.trace.span import Span

logger = lambda_logger
event_logger = lambda_event_logger

_INSTRUMENTATION_LIB_NAME = "dt.agent.python.awslambda-in"


class IncomingAwsLambdaInstrumentor(BaseInstrumentor):
    def __init__(self):
        # will be initialized when instrument is called
        self._agent = None  # type: Optional[DynatraceAgent]
        self._extension = None  # type: Optional[FastResponseExtension]

        self.reset_instrumentor_context()

        self.instrumentation_disabled = False
        self.is_coldstart = True

    def instrumentation_dependencies(self) -> Collection[str]:
        return ()

    def reset_instrumentor_context(self):
        self.span: Optional[Span] = None
        self.activation = None
        self.mapper = None  # type: Optional[events.AwsEventAttributeMapper]

    def _instrument(self, **kwargs) -> Callable:
        self.instrumentation_disabled = False

        try:
            self._set_agent(kwargs["dt_agent"])
            handler_function = kwargs["handler_function"]
            if _get_python_version() >= (3, 7):
                return instrument_py37_or_greater(self, handler_function)

            raise ValueError(f"Cannot instrument runtime {sys.version}")
        except Exception:
            self.instrumentation_disabled = True
            raise

    def _set_agent(self, agent: DynatraceAgent):
        self._agent = agent
        self._extension = FastResponseExtension(agent)

    def _uninstrument(self, **kwargs) -> Callable:
        self.instrumentation_disabled = True

        handler_function = kwargs["handler_function"]
        return handler_function.__wrapped__


def _get_python_version():
    return sys.version_info


def instrument_py37_or_greater(
    instrumentor: IncomingAwsLambdaInstrumentor, handler_function
) -> Callable:
    wrapped_handler = wrap_handler(instrumentor, handler_function)

    instrumentor._extension.register_and_signal_next()  # pylint:disable=protected-access

    return wrapped_handler


def _create_span(
    instrumentor: IncomingAwsLambdaInstrumentor,
    event: LambdaEvent,
    context: LambdaContext,
):
    agent = instrumentor._agent  # pylint:disable=protected-access
    is_coldstart = instrumentor.is_coldstart
    if is_coldstart:
        instrumentor.is_coldstart = False
        aws_resource = resources.get_resource_from(context)
        agent.tracer_provider.merge_resource(aws_resource)

    mapper = events.get_event_mapper(agent.config, event, context)
    semconv_attrs = {
        semconv.FAAS_COLDSTART: is_coldstart,
        semconv.AWS_LAMBDA_INVOKED_ARN: context.invoked_function_arn,
    }
    mapper.apply_to(semconv_attrs)
    parent_context, links = mapper.extract_parent(Context())

    # In future there might be different span kinds depending on the mapper.
    span_name = context.function_name or "<AWS Lambda>"
    tracer = agent.tracer_provider.get_tracer(_INSTRUMENTATION_LIB_NAME, "")

    agent.tracer_provider.end_global_tracing_suppression()

    activation = tracer.start_as_current_span(
        span_name,
        context=parent_context,
        kind=mapper.span_kind,
        attributes=semconv_attrs,
        links=links,
        record_exception=False,
        end_on_exit=True,
    )
    instrumentor.span = (
        activation.__enter__()  # pylint:disable=unnecessary-dunder-call
    )
    instrumentor.activation = activation
    instrumentor.mapper = mapper


def wrap_handler(
    instrumentor: IncomingAwsLambdaInstrumentor, orig_handler_func: Callable
):
    """Wraps the given handler function to create a span once the wrapped
    function is invoked.
    """

    # pylint:disable=unused-argument
    @wrapt.decorator
    def instrumented_handler(wrapped, instance, args, kwargs):
        logger.debug(
            "Calling handler, coldstart: %s", instrumentor.is_coldstart
        )
        event_logger.debug(
            "Lambda handler arguments: args=%s, kwargs=%s", args, kwargs
        )
        try:
            if instrumentor.instrumentation_disabled:
                return wrapped(*args, **kwargs)
            try:
                _create_span(instrumentor, args[0], args[1])
            except Exception as ex:  # pylint:disable=broad-except
                logger.warning("Could not create span", exc_info=ex)

            try:
                result = wrapped(*args, **kwargs)
            except Exception as ex:  # pylint:disable=broad-except
                record_exception(instrumentor.span, ex)
                raise
            else:
                _apply_handler_result(instrumentor, result)
            finally:
                _finish_span(instrumentor)
            return result
        finally:
            # make sure extension is called in every case
            logger.debug("Finished handler, calling flush")
            instrumentor._extension.flush_spans()  # pylint:disable=protected-access

    # monkey patch the decorator onto the orig handler function
    # pylint: disable=no-value-for-parameter
    return instrumented_handler(orig_handler_func)


def _apply_handler_result(instrumentor: IncomingAwsLambdaInstrumentor, result):
    logger.debug("Applying handler result to span")
    if instrumentor.instrumentation_disabled:
        return
    if not instrumentor.mapper or not instrumentor.span:
        logger.warning("Tried to apply handler result but no span/mapper")
        return
    try:
        instrumentor.mapper.apply_result_to(result, instrumentor.span)
    except Exception as ex:  # pylint:disable=broad-except
        logger.warning("Failed to apply handler result to span", exc_info=ex)


def _finish_span(instrumentor: IncomingAwsLambdaInstrumentor):
    try:
        try:
            if instrumentor.activation is not None:
                instrumentor.activation.__exit__(None, None, None)
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning("Failed to end span", exc_info=ex)

        instrumentor.reset_instrumentor_context()
    finally:
        try:
            # re-enable tracing suppression until next lambda invocation
            agent = instrumentor._agent  # pylint:disable=protected-access
            agent.tracer_provider.begin_global_tracing_suppression()
        except Exception as ex:  # pylint:disable=broad-except
            logger.warning(
                "Failed to re-enable global tracing suppression", exc_info=ex
            )

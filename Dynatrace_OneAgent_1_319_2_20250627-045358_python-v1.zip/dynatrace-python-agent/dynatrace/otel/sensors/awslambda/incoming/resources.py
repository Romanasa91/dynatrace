import os
import typing

import dynatrace.odin.semconv.v1 as semconv
from dynatrace.opentelemetry.tracing._logging.loggers import lambda_logger
from dynatrace.otel.sensors.awslambda.common.types import LambdaContext
from dynatraceotel.sdk.resources import Resource

logger = lambda_logger

_ACCOUNT_ID_ARN_IDX = 4
_NUM_ARN_PARTS = 7


def get_resource_from(context: LambdaContext) -> Resource:
    faas_id, account_id = _parse_function_arn(context)
    resource_labels = {
        semconv.FAAS_NAME: context.function_name,
        semconv.FAAS_ID: faas_id,
        semconv.CLOUD_PROVIDER: "aws",
        semconv.CLOUD_ACCOUNT_ID: account_id,
        semconv.CLOUD_REGION: os.environ["AWS_REGION"],
    }

    if context.function_version:
        resource_labels[semconv.FAAS_VERSION] = context.function_version

    _set_function_mem_size(resource_labels)

    return Resource(resource_labels)


def _parse_function_arn(context: LambdaContext):
    function_arn = context.invoked_function_arn
    account_id = ""
    if not function_arn:
        logger.warning("No lambda function arn when extracting resource")
        return function_arn, account_id

    arn_split = function_arn.split(":", _NUM_ARN_PARTS)[:_NUM_ARN_PARTS]

    try:
        account_id = arn_split[_ACCOUNT_ID_ARN_IDX]
    except IndexError:
        logger.warning("Could not extract accountId from %s", function_arn)

    faas_id = ":".join(arn_split)

    return faas_id, account_id


def _set_function_mem_size(resource_labels: typing.Dict):
    mem_size = os.environ.get("AWS_LAMBDA_FUNCTION_MEMORY_SIZE")
    if not mem_size:
        return

    try:
        parsed_mem_size = int(mem_size)
    except ValueError:
        logger.warning(
            "Resource attribute %s: Expected numeric but was %s",
            semconv.FAAS_MAX_MEMORY,
            mem_size,
        )
        return

    resource_labels[semconv.FAAS_MAX_MEMORY] = parsed_mem_size

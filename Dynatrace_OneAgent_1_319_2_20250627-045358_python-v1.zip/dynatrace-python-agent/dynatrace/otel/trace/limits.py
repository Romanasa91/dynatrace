from typing import Callable, Optional

from dynatrace.opentelemetry.tracing._logging.loggers import tracer_logger
from dynatraceotel.sdk.environment_variables import (
    OTEL_ATTRIBUTE_COUNT_LIMIT,
    OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT,
    OTEL_EVENT_ATTRIBUTE_COUNT_LIMIT,
    OTEL_LINK_ATTRIBUTE_COUNT_LIMIT,
    OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT,
    OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT,
    OTEL_SPAN_EVENT_COUNT_LIMIT,
    OTEL_SPAN_LINK_COUNT_LIMIT,
)
from dynatraceotel.sdk.trace import SpanLimits


def make_agent_span_limits() -> SpanLimits:
    return _make_limits(lambda key: None)


def make_app_span_limits() -> SpanLimits:
    def getter(env_key: str) -> Optional[int]:
        key = _adjust_otel_env_key(env_key)
        try:
            return SpanLimits._from_env_if_absent(  # pylint: disable=protected-access
                None, key
            )
        except ValueError as ex:
            tracer_logger.warning("Invalid span limit: %s", ex)
            # will lookup env with the isolated (_DTOTEL...) key so in turn
            # the default value will be assigned
            return None

    return _make_limits(getter)


def _make_limits(getter: Callable[[str], Optional[int]]) -> SpanLimits:
    return SpanLimits(
        max_attributes=getter(OTEL_ATTRIBUTE_COUNT_LIMIT),
        max_events=getter(OTEL_SPAN_EVENT_COUNT_LIMIT),
        max_links=getter(OTEL_SPAN_LINK_COUNT_LIMIT),
        max_span_attributes=getter(OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT),
        max_event_attributes=getter(OTEL_EVENT_ATTRIBUTE_COUNT_LIMIT),
        max_link_attributes=getter(OTEL_LINK_ATTRIBUTE_COUNT_LIMIT),
        max_attribute_length=getter(OTEL_ATTRIBUTE_VALUE_LENGTH_LIMIT),
        max_span_attribute_length=getter(
            OTEL_SPAN_ATTRIBUTE_VALUE_LENGTH_LIMIT
        ),
    )


def _adjust_otel_env_key(key: str) -> str:
    prefix = "_DT"
    if key.startswith(prefix):
        return key[len(prefix) :]
    return key

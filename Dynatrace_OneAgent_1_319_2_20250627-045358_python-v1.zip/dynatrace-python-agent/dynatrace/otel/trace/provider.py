import enum
import logging
import weakref
from threading import Lock
from typing import Optional, Sequence, Tuple, Union

import dynatrace.odin.semconv.v1 as semconv
from dynatrace.opentelemetry.tracing._config.settings import OTelSettings
from dynatrace.opentelemetry.tracing._logging.loggers import tracer_logger
from dynatrace.opentelemetry.tracing._util.context import (
    TRACING_SUPPRESSION_KEY,
)
from dynatrace.opentelemetry.tracing._util.meta import mark_propagated_now
from dynatrace.otel.trace import limits
from dynatraceotel import trace as trace_api
from dynatraceotel.context import Context, get_value
from dynatraceotel.sdk.resources import Resource
from dynatraceotel.sdk.trace import (
    ConcurrentMultiSpanProcessor,
    SpanLimits,
    SynchronousMultiSpanProcessor,
    Tracer,
    TracerProvider,
    sampling,
)
from dynatraceotel.sdk.trace.id_generator import IdGenerator
from dynatraceotel.sdk.util.instrumentation import (
    InstrumentationInfo,
    InstrumentationScope,
)
from dynatraceotel.trace.span import NonRecordingSpan
from dynatraceotel.util import types

OUTGOING_SPAN_KINDS = (trace_api.SpanKind.CLIENT, trace_api.SpanKind.PRODUCER)
INCOMING_SPAN_KINDS = (trace_api.SpanKind.SERVER, trace_api.SpanKind.CONSUMER)
_SUPPRESSED_INSTRUMENTED_LIBRARIES = frozenset(
    (
        "opentelemetry.instrumentation.aiohttp-client",
        "opentelemetry.instrumentation.requests",
        "opentelemetry.instrumentation.urllib3",
    )
)


class DtSuppressedSpan(trace_api.NonRecordingSpan):
    def __init__(self, parent_span: trace_api.Span):
        super().__init__(parent_span.get_span_context())
        self._dt_parent_span = weakref.ref(parent_span)
        self._kind = getattr(parent_span, "kind", None)

    @property
    def kind(self) -> trace_api.SpanKind:
        return self._kind

    def mark_parent_propagated_now(self):
        parent_span = self._dt_parent_span()
        if parent_span:
            mark_propagated_now(parent_span)


class DtTracerKind(enum.Enum):
    AGENT_TRACER = 1
    APP_TRACER = 2
    APP_TRACER_SUPPRESSED = 3

    @classmethod
    def from_name(
        cls, name: str, settings: Optional[OTelSettings]
    ) -> "DtTracerKind":
        if name.startswith("dt.agent.python."):
            return cls.AGENT_TRACER
        if (
            name in _SUPPRESSED_INSTRUMENTED_LIBRARIES
            or settings
            and settings.is_disabled_sensor(name)
        ):
            return cls.APP_TRACER_SUPPRESSED
        return cls.APP_TRACER


class DtTracer(Tracer):
    def __init__(
        self,
        tracer_provider: "DtTracerProvider",
        instrumentation_info: InstrumentationInfo,
        tracer_kind: DtTracerKind,
        instrumentation_scope: InstrumentationScope,
    ):
        super().__init__(
            tracer_provider.sampler,
            tracer_provider.resource,
            tracer_provider._active_span_processor,
            tracer_provider.id_generator,
            instrumentation_info,
            tracer_provider._dt_get_span_limits(tracer_kind),
            instrumentation_scope,
        )
        self._tracer_provider = tracer_provider
        self._dt_tracer_kind = tracer_kind

    @property
    def resource(self) -> Resource:
        # make sure that we also return the same resource as the DtTracerProvider
        # after DtTracerProvider.freeze_resource was called.
        return self._tracer_provider.resource

    @resource.setter
    def resource(self, value):
        # provide a setter since the super constructor will try to set the
        # resource and fail if it is not available.
        pass

    def start_span(
        self,
        name: str,
        context: Optional[Context] = None,
        kind: trace_api.SpanKind = trace_api.SpanKind.INTERNAL,
        attributes: Optional[types.Attributes] = None,
        links: Optional[Sequence[trace_api.Link]] = (),
        start_time: Optional[int] = None,
        record_exception: bool = True,
        set_status_on_exception: bool = True,
    ) -> trace_api.Span:
        context, links = self._adjust_parent_span(context, links)
        if self._tracer_provider.is_tracing_globally_suppressed():
            tracer_logger.debug(
                "'%s' suppressing span '%s': Tracing globally disabled.",
                _get_instrumentation_scope(self),
                name,
            )
            # instead of not sampling the spans return the invalid span since it
            # gets ignored by propagators and does not create a span hierarchy
            return trace_api.INVALID_SPAN
        if get_value(TRACING_SUPPRESSION_KEY, context):
            tracer_logger.debug(
                "'%s' suppressing span '%s': Tracing disabled by context.",
                _get_instrumentation_scope(self),
                name,
            )
            # spans created while e.g. export is running
            return _get_or_create_suppressed_span(context)

        suppressed_span = self._determine_suppressed_span(context, kind, name)
        if suppressed_span is not None:
            return suppressed_span

        self._tracer_provider.freeze_resource()

        span = super().start_span(
            name=name,
            context=context,
            kind=kind,
            attributes=attributes,
            links=links,
            start_time=start_time,
            record_exception=record_exception,
            set_status_on_exception=set_status_on_exception,
        )

        if tracer_logger.isEnabledFor(logging.DEBUG):
            tracer_logger.debug(
                "%s: Started %s", _get_instrumentation_scope(self), str(span)
            )

        return span

    def _adjust_parent_span(
        self, context: Optional[Context], links: Sequence[trace_api.Link]
    ) -> Tuple[Optional[Context], Sequence[trace_api.Link]]:
        if (
            self._dt_tracer_kind == DtTracerKind.AGENT_TRACER
            or self._tracer_provider.allow_explicit_parent
        ):
            return context, links

        active_parent = trace_api.get_current_span()
        if not active_parent.get_span_context().is_valid or context is None:
            return context, links

        requested_parent = trace_api.get_current_span(context)

        context = trace_api.set_span_in_context(active_parent, context)
        parent_uplink = trace_api.Link(
            requested_parent.get_span_context(),
            attributes={semconv.DT_PARENT_IS_SUPPRESSED_PRIMARY: True},
        )
        return context, tuple(links) + (parent_uplink,)

    def _determine_suppressed_span(
        self,
        parent_context: Optional[Context],
        kind: trace_api.SpanKind,
        name,
    ) -> Optional[trace_api.Span]:
        if self._dt_tracer_kind == DtTracerKind.AGENT_TRACER:
            # we do not further suppress agent spans
            return None

        if self._dt_tracer_kind == DtTracerKind.APP_TRACER_SUPPRESSED:
            tracer_logger.debug(
                "'%s' suppressing span '%s': Library disabled by config.",
                _get_instrumentation_scope(self),
                name,
            )
            # always suppress spans of excluded tracers
            return _get_or_create_suppressed_span(parent_context)

        parent_span = trace_api.get_current_span(parent_context)
        if _is_valid_local_span(parent_span):
            parent_kind = getattr(parent_span, "kind", None)
            if parent_kind in OUTGOING_SPAN_KINDS:
                tracer_logger.debug(
                    "'%s' suppressing span '%s' because its local parent has kind %s.",
                    _get_instrumentation_scope(self),
                    name,
                    parent_kind,
                )
                # suppress local child spans of client/producer parent spans
                return _get_or_create_suppressed_span(parent_context)
        elif kind not in INCOMING_SPAN_KINDS:
            tracer_logger.debug(
                "'%s' suppressing span '%s' because it has no local parent and kind %s.",
                _get_instrumentation_scope(self),
                name,
                kind,
            )
            # suppress root spans that don't have kind Server/Consumer
            return trace_api.INVALID_SPAN
        return None


def _is_valid_local_span(parent_span: trace_api.Span) -> bool:
    parent_context = parent_span.get_span_context()
    return parent_context.is_valid and not parent_context.is_remote


def _get_or_create_suppressed_span(
    parent_context: Optional[Context],
) -> trace_api.Span:
    parent_span = trace_api.get_current_span(parent_context)
    if isinstance(parent_span, DtSuppressedSpan):
        suppressed_span = parent_span
    elif isinstance(parent_span, NonRecordingSpan):
        # DtSuppressedSpan is a NonRecordingSpan, so need to check this after the other isinstance
        return parent_span
    else:
        suppressed_span = DtSuppressedSpan(parent_span)

    suppressed_span.mark_parent_propagated_now()
    return suppressed_span


def _get_instrumentation_scope(tracer: DtTracer) -> InstrumentationScope:
    return tracer._instrumentation_scope  # pylint:disable=protected-access


class DtMultiSpanProcessor(SynchronousMultiSpanProcessor):
    def force_flush(self, timeout_millis: int = None) -> bool:
        if timeout_millis is not None:
            return super().force_flush(timeout_millis)
        # let each span processor use its own default timeout if none was given
        for sp in self._span_processors:
            if not sp.force_flush():  # pylint:disable=no-member
                return False
        return True


class DtTracerProvider(TracerProvider):
    def __init__(
        self,
        sampler: Optional[sampling.Sampler] = None,
        resource: Optional[Resource] = None,
        shutdown_on_exit: bool = True,
        active_span_processor: Union[
            SynchronousMultiSpanProcessor, ConcurrentMultiSpanProcessor, None
        ] = None,
        id_generator: Optional[IdGenerator] = None,
        span_limits: Optional[SpanLimits] = None,
        otel_settings: Optional[OTelSettings] = None,
    ) -> None:
        super().__init__(
            sampler,
            resource,
            shutdown_on_exit,
            active_span_processor or DtMultiSpanProcessor(),
            id_generator,
            span_limits or limits.make_agent_span_limits(),
        )
        self._is_resource_frozen = False
        self._lock = Lock()
        self._is_global_tracing_suppressed = False
        self.dt_disabled_add_span_processor = False
        self._otel_settings = (
            otel_settings  # TODO: Can we replace None with default settings?
        )
        self.allow_explicit_parent = (
            self._otel_settings and self._otel_settings.allow_explicit_parent
        )
        self._app_span_limits = limits.make_app_span_limits()

    def _dt_get_span_limits(self, tracer_kind: DtTracerKind):
        if tracer_kind == DtTracerKind.AGENT_TRACER:
            return self._span_limits
        return self._app_span_limits

    def get_tracer(
        self,
        instrumenting_module_name: str,
        instrumenting_library_version: Optional[str] = None,
        schema_url: Optional[str] = None,
        attributes: Optional[types.Attributes] = None,
    ) -> "trace_api.Tracer":
        if not instrumenting_module_name:
            instrumenting_module_name = ""
            tracer_logger.error("get_tracer called with missing module name.")

        tracer_kind = DtTracerKind.from_name(
            instrumenting_module_name, self._otel_settings
        )
        return DtTracer(
            self,
            InstrumentationInfo(
                instrumenting_module_name,
                instrumenting_library_version,
                schema_url,
            ),
            tracer_kind,
            InstrumentationScope(
                instrumenting_module_name,
                instrumenting_library_version,
                schema_url,
                attributes,
            ),
        )

    def force_flush(self, timeout_millis: int = None):
        # make none the default value for the timeout
        if timeout_millis is None:
            return self._active_span_processor.force_flush()
        return self._active_span_processor.force_flush(timeout_millis)

    def add_span_processor(self, span_processor) -> None:
        if not self.dt_disabled_add_span_processor:
            super().add_span_processor(span_processor)
        else:
            tracer_logger.info(
                "Adding additional span processors is disabled. Ignoring %s",
                type(span_processor).__name__,
            )

    def freeze_resource(self):
        if self._is_resource_frozen:
            return
        with self._lock:
            self._is_resource_frozen = True

    def merge_resource(self, other: Resource):
        if self._check_and_log_if_resource_frozen(other):
            return
        with self._lock:
            if self._check_and_log_if_resource_frozen(other):
                return
            self._resource = self._resource.merge(other)

    def _check_and_log_if_resource_frozen(self, other: Resource) -> bool:
        if not self._is_resource_frozen:
            return False
        if tracer_logger.isEnabledFor(logging.WARNING):
            tracer_logger.warning(
                "Tried to merge resource '%s' when already frozen.",
                other.attributes,
            )
        return True

    def begin_global_tracing_suppression(self):
        self._is_global_tracing_suppressed = True

    def is_tracing_globally_suppressed(self):
        return self._is_global_tracing_suppressed

    def end_global_tracing_suppression(self):
        self._is_global_tracing_suppressed = False

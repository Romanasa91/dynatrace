from dynatraceotel.propagate import *  # noqa pylint:disable=unused-wildcard-import,wildcard-import
from dynatraceotel.propagators import textmap


# pylint:disable=function-redefined
def set_global_textmap(http_text_format: textmap.TextMapPropagator) -> None:
    # Suppressed
    pass

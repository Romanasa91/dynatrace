import importlib
import logging
import pkgutil
import re
import sys
from collections import namedtuple
from typing import Optional

import dynatraceotel.baggage
import dynatraceotel.context
import dynatraceotel.environment_variables
import dynatraceotel.propagate
import dynatraceotel.trace
from dynatrace.opentelemetry.tracing._config.settings import DtConfig
from dynatrace.otel.bridge import bridgepropagate

logger = logging.getLogger("dynatrace.inject.agent")

_OTEL_MAX_SUPPORTED_VERSION = "1.34.0"
_OTEL_VERSION_PATTERN = re.compile(
    r"^(?P<major>\d+)"
    r"\.(?P<minor>\d+)"
    r"(?:\.(?P<patch>\d+))?"
    r"(?P<pre>(?:(?:a|b|rc)\d)?(?:\.post\d)?(?:\.dev\d)?)?"
)

_OTEL_API_NAMESPACE = "opentelemetry"

_Version = namedtuple("_Version", ("major", "minor", "patch", "pre"))


def connect_otel_api(config: DtConfig):
    if not config.otel.enable_integration:
        return

    otel_api_version = _get_api_version_and_log()
    if not otel_api_version:
        logger.info(
            "OpenTelemetry integration enabled but no %s-api installed",
            _OTEL_API_NAMESPACE,
        )
        return

    agent_api_version = config.otel.override_max_api_version
    if agent_api_version:
        logging.info(
            "Dynatrace SDK (%s) version overridden to '%s'",
            _OTEL_MAX_SUPPORTED_VERSION,
            agent_api_version,
        )
    else:
        agent_api_version = _OTEL_MAX_SUPPORTED_VERSION

    if not _is_otel_version_compatible(otel_api_version, agent_api_version):
        logger.info(
            "%s-api version (%s) is not compatible with Dynatrace SDK (%s).",
            _OTEL_API_NAMESPACE,
            otel_api_version,
            agent_api_version,
        )
        return

    # We "preload" all OpenTelemetry API packages we want to replace in
    # sys.modules.
    redirected_pkgs = (
        dynatraceotel.propagate,
        dynatraceotel.trace,
        # We don't want to replace these, as we have no interaction with these
        # submodules, and replacing less makes it less likely that we break anything
        #
        # dynatraceotel.baggage, # Leave
        # dynatraceotel.environment_variables,
        # Additionally, we cannot replace these,
        # since they are namespace modules and we would block users from loading
        # submodules that do not exist in the dynatraceotel module.
        #
        # dynatraceotel.propagators,
        # dynatraceotel.util,
    )

    opentelemetry = importlib.import_module(_OTEL_API_NAMESPACE)

    for root_pkg in redirected_pkgs:
        namestem = root_pkg.__name__[len("dynatraceotel.") :]
        otelrootname = "opentelemetry." + namestem
        sys.modules[otelrootname] = root_pkg
        setattr(opentelemetry, namestem, root_pkg)
        for subpkg in pkgutil.walk_packages(root_pkg.__path__):
            otelname = otelrootname + "." + subpkg.name
            dtname = root_pkg.__name__ + "." + subpkg.name
            sys.modules[otelname] = importlib.import_module(dtname)

    # To disable the textmap propagator setter
    opentelemetry.propagate = bridgepropagate
    sys.modules["opentelemetry.propagate"] = bridgepropagate

    # For Context we need something special because the main module selects
    # only certain submodules.
    root_pkg = dynatraceotel.context
    opentelemetry.context = root_pkg
    otelrootname = "opentelemetry.context"
    sys.modules[otelrootname] = root_pkg
    for subpkg in pkgutil.walk_packages(root_pkg.__path__):
        dtname = root_pkg.__name__ + "." + subpkg.name
        module = sys.modules.get(dtname)
        if module:
            otelname = otelrootname + "." + subpkg.name
            sys.modules[otelname] = module


def _get_api_version_and_log():
    try:
        importlib.import_module(_OTEL_API_NAMESPACE)
    except ImportError:
        return None

    api_version = _get_otel_version(_OTEL_API_NAMESPACE + ".version")
    if api_version:
        logger.info(
            "%s-api installed in version %s", _OTEL_API_NAMESPACE, api_version
        )
    sdk_version = _get_otel_version(_OTEL_API_NAMESPACE + ".sdk.version")
    if sdk_version:
        logger.warning(
            "%s-sdk installed in version %s", _OTEL_API_NAMESPACE, sdk_version
        )
    return api_version


def _get_otel_version(version_path: str):
    try:
        return getattr(importlib.import_module(version_path), "__version__")
    except Exception:  # pylint: disable=broad-except
        return None


def _is_otel_version_compatible(
    otel_api_version: str, agent_api_version: str
) -> bool:
    agent_version = _parse_version_str(agent_api_version)
    if agent_version is None:
        return False

    otel_version = _parse_version_str(otel_api_version)
    if otel_version is None:
        return False

    # pre release versions must match exactly
    if (
        otel_version.major == 0
        or otel_version.pre
        or agent_version.major == 0
        or agent_version.pre
    ):
        return agent_version == otel_version

    if otel_version.major != agent_version.major:
        return False

    return otel_version.minor <= agent_version.minor


def _parse_version_str(ver: str) -> Optional["_Version"]:
    if ver is None:
        return None
    match = _OTEL_VERSION_PATTERN.fullmatch(ver.strip())
    if not match:
        return None
    patch = match.group("patch")
    if patch is not None:
        patch = int(patch)

    return _Version(
        int(match.group("major")),
        int(match.group("minor")),
        patch,
        match.group("pre"),
    )

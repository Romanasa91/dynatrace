import abc
from logging import Logger
from types import ModuleType

import wrapt


class BaseInstrumentationHook(abc.ABC):
    library_name: str
    version_specifiers: str

    def setup(self, logger: Logger):
        hook = self._make_hook(logger)
        wrapt.when_imported(self.library_name)(hook)

    def _make_hook(self, logger: Logger):
        def _hook(imported_module):
            try:
                # check for compatible version
                if not self._is_version_compatible(imported_module, logger):
                    return

                self._instrument(imported_module)
                logger.debug("Instrumenting '%s'", self.library_name)
            except Exception as ex:  # pylint:disable=broad-except
                logger.error(
                    "Failed to instrument '%s': %s", self.library_name, str(ex)
                )

        return _hook

    def _is_version_compatible(self, mod: ModuleType, logger: Logger) -> bool:
        if self.version_specifiers == "":
            return True

        # import late to save some time when no instrumentation is loaded
        from packaging.specifiers import (  # pylint:disable=import-outside-toplevel
            SpecifierSet,
        )

        version = self._get_library_version(mod)
        if version not in SpecifierSet(self.version_specifiers):
            logger.warning(
                "Disabling instrumentation '%s' because version '%s' is not "
                "supported. Supported versions are: '%s'.",
                self.library_name,
                version,
                self.version_specifiers,
            )
            return False

        return True

    @abc.abstractmethod
    def _get_library_version(self, mod: ModuleType) -> str:
        pass

    @abc.abstractmethod
    def _instrument(self, mod: ModuleType):
        pass

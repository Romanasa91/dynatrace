from typing import Any

from dynatrace.opentelemetry.tracing._config.settings import ConnectionSettings
from dynatrace.opentelemetry.tracing._logging.loggers import core_logger

AWS_SDK_CONNECTION_TIMEOUT = 500
AWS_SDK_REQUEST_TIMEOUT = 2000


def get_auth_token(
    connection: ConnectionSettings,
) -> str:
    auth_token = connection.auth_token
    if connection.auth_token_secrets_manager_arn is not None:
        auth_token = _get_auth_token_from_secrets_manager(
            connection.auth_token_secrets_manager_arn
        )
    return auth_token


def _get_auth_token_from_secrets_manager(
    auth_token_secrets_manager_arn: str,
) -> Any:
    region_name = _get_region_from_arn(auth_token_secrets_manager_arn)
    if not region_name:
        error = f"Failed to fetch auth-token from AWS Secrets Manager. AWS region can't be extracted from the provided ARN {auth_token_secrets_manager_arn}."
        core_logger.error(error)
        raise ValueError(error)

    import boto3  # pylint:disable=import-outside-toplevel
    import botocore  # pylint:disable=import-outside-toplevel

    config = botocore.client.Config(
        connect_timeout=AWS_SDK_CONNECTION_TIMEOUT,
        read_timeout=AWS_SDK_REQUEST_TIMEOUT,
        region_name=region_name,
    )

    session = boto3.session.Session()
    client = session.client(
        service_name="secretsmanager",
        config=config,
    )
    try:
        get_secret_value_response = client.get_secret_value(
            SecretId=auth_token_secrets_manager_arn
        )
    except Exception as ex:
        core_logger.error(
            "Failed to fetch auth-token from %s: %s",
            auth_token_secrets_manager_arn,
            ex,
        )
    else:
        if "SecretString" in get_secret_value_response:
            return get_secret_value_response["SecretString"]

    error = f"Failed to fetch auth-token from AWS Secrets Manager with ARN {auth_token_secrets_manager_arn}."
    core_logger.error(error)
    raise ValueError(error)


def _get_region_from_arn(arn: str) -> Any:
    parts = arn.split(":")
    if len(parts) < 7:
        return ""

    return parts[3]

import abc
import sys
from logging import Logger
from typing import Any, Callable, List, Optional, Union

import wrapt
from packaging.specifiers import SpecifierSet

from dynatraceotel.instrumentation.utils import unwrap

_WrapperT = Callable[..., Any]


class EntityBuilder(abc.ABC):
    @abc.abstractmethod
    def restricted_to(
        self, version_range: Union[str, SpecifierSet]
    ) -> "EntityBuilder":
        pass

    def use(self, wrapper: _WrapperT) -> None:
        pass


class TransformableEntity(EntityBuilder):
    def __init__(
        self,
        transformer: "Transformer",
        module: str,
        class_name: Optional[str],
        func_name: str,
    ):
        self._transformer = transformer
        self.module = module
        self.class_name = class_name
        self.func_name = func_name
        self._wrapper = None
        self._version_matcher: Optional[SpecifierSet] = None
        self._ignore_if_error_on_transform = False

    def restricted_to(
        self, version_range: Union[str, SpecifierSet]
    ) -> "EntityBuilder":
        if isinstance(version_range, str):
            self._version_matcher = SpecifierSet(version_range)
        else:
            self._version_matcher = version_range
        return self

    def use(self, wrapper: _WrapperT) -> None:
        self._wrapper = wrapper
        self._transformer._register_entity(  # pylint:disable=protected-access
            self
        )

    @property
    def wrapper(self) -> _WrapperT:
        return self._wrapper

    def matches_version(self, version: str) -> bool:
        matcher = self._version_matcher
        return True if not matcher else version in matcher

    @property
    def full_qualified_name(self) -> str:
        return f"{self.module}.{self.qualified_func_name}"

    @property
    def qualified_func_name(self) -> str:
        return (
            f"{self.class_name}.{self.func_name}"
            if self.class_name
            else self.func_name
        )

    @property
    def ignore_if_error_on_transform(self) -> bool:
        return self._ignore_if_error_on_transform


class Transformer:
    def __init__(self, logger: Logger, name: str, version: str):
        self._logger = logger
        self._name = name
        self._version = version
        self._registered_entities: List[TransformableEntity] = []

    def with_class_func(self, full_qualified_name: str) -> EntityBuilder:
        mod, class_name, func_name = full_qualified_name.rsplit(".", 2)
        return TransformableEntity(self, mod, class_name, func_name)

    def with_module_func(self, full_qualified_name: str) -> EntityBuilder:
        mod, func_name = full_qualified_name.rsplit(".", 1)
        return TransformableEntity(self, mod, None, func_name)

    def _register_entity(self, entity: "TransformableEntity") -> None:
        self._registered_entities.append(entity)

    def matches_version_spec(
        self, spec: str, pre_releases: bool = True
    ) -> bool:
        return SpecifierSet(spec).contains(
            self._version, prereleases=pre_releases
        )

    def apply(self) -> None:
        transformed: List[TransformableEntity] = []
        try:
            for entity in self._registered_entities:
                if self._transform_entity(entity):
                    transformed.append(entity)
        except Exception as ex:  # pylint:disable=broad-except
            self._logger.error(
                "Error while transforming %r:", self._name, exc_info=ex
            )
            self._restore(transformed)

    def _transform_entity(self, entity: TransformableEntity) -> bool:
        if not entity.matches_version(self._version):
            return False

        try:
            wrapt.wrap_function_wrapper(
                entity.module, entity.qualified_func_name, entity.wrapper
            )
        except Exception as ex:
            self._logger.warning(
                "Error transforming entity %r: %s",
                entity.full_qualified_name,
                ex,
            )
            if entity.ignore_if_error_on_transform:
                return False
            raise

        return True

    def restore(self) -> None:
        self._restore(self._registered_entities)

    def _restore(self, transformed: List[TransformableEntity]) -> None:
        for transformable in transformed:
            try:
                self._restore_entity(transformable)
            except Exception as ex:  # pylint:disable=broad-except
                self._logger.warning(
                    "Error while restoring %r: %s",
                    transformable.full_qualified_name,
                    ex,
                )

    @staticmethod
    def _restore_entity(transformable: TransformableEntity) -> None:
        mod = sys.modules[transformable.module]
        obj = (
            getattr(mod, transformable.class_name)
            if transformable.class_name
            else mod
        )
        unwrap(obj, transformable.func_name)

import platform
import sys

import dynatrace.odin.semconv.v1 as semconv
import dynatrace.otel.util.secretfetch
from dynatrace.opentelemetry.tracing._config.reader import (
    banner,
    get_configuration,
)
from dynatrace.opentelemetry.tracing._config.settings import DtConfig
from dynatrace.opentelemetry.tracing._export.exporter import DtSpanExporter
from dynatrace.opentelemetry.tracing._export.processor import DtSpanProcessor
from dynatrace.opentelemetry.tracing._sampler import DT_SAMPLER
from dynatrace.otel import bridge, version
from dynatrace.otel.propagation.textmap import DtOdinTextMapPropagator
from dynatrace.otel.trace.provider import DtTracerProvider
from dynatraceotel import trace as api_trace
from dynatraceotel.propagate import set_global_textmap
from dynatraceotel.sdk.trace import Resource

TESTABILITY_AGENT_VERSION_KEY = "dt_testability_agent_version"
TESTABILITY_OS_TYPE = "dt_testability_os_type"
TESTABILITY_OS_DESCRIPTION = "dt_testability_os_description"


class DynatraceAgent:
    def __init__(self, tracer_provider: DtTracerProvider, config: DtConfig):
        self.tracer_provider = tracer_provider
        self.config = config


def initialize(**kwargs) -> DynatraceAgent:
    """Initializes the agent from the given parameters.

    Args:
        kwargs: additional programmatic configuration options
            .. seealso:: modules :py:mod `dynatrace.opentelemetry`
    """
    config = get_configuration(**kwargs)
    config.connection.auth_token = (
        dynatrace.otel.util.secretfetch.get_auth_token(config.connection)
    )

    tracer_provider = DtTracerProvider(
        sampler=DT_SAMPLER,
        resource=_create_resource(**kwargs),
        otel_settings=config.otel,
    )

    if kwargs.get("enable_global_tracing_suppression"):
        tracer_provider.begin_global_tracing_suppression()
    api_trace.set_tracer_provider(tracer_provider)

    _setup_propagator(config)
    _setup_span_processor(tracer_provider, config)

    bridge.connect_otel_api(config)
    return DynatraceAgent(tracer_provider, config)


def _setup_propagator(config: DtConfig):
    propagator = DtOdinTextMapPropagator(config=config)
    set_global_textmap(propagator)


def _setup_span_processor(tracer_provider: DtTracerProvider, config: DtConfig):
    exporter = DtSpanExporter(config=config)
    processor = DtSpanProcessor(exporter=exporter, config=config)

    tracer_provider.add_span_processor(processor)
    tracer_provider.dt_disabled_add_span_processor = True


def _create_resource(**kwargs) -> Resource:
    os_type = kwargs.get(
        TESTABILITY_OS_TYPE,
        banner._get_os_type(),  # pylint: disable=protected-access
    )
    os_desc = kwargs.get(TESTABILITY_OS_DESCRIPTION, platform.platform())

    resources = {
        semconv.TELEMETRY_SDK_NAME: "odin",
        semconv.TELEMETRY_SDK_LANGUAGE: "python",
        semconv.TELEMETRY_SDK_VERSION: version.FULL_VERSION,
        semconv.DT_OS_TYPE: os_type,
        semconv.DT_OS_DESCRIPTION: os_desc,
        semconv.PROCESS_RUNTIME_NAME: sys.implementation.name,
        semconv.PROCESS_RUNTIME_DESCRIPTION: sys.version,
        semconv.PROCESS_RUNTIME_VERSION: banner._get_py_version(),  # pylint: disable=protected-access
    }

    return Resource(resources)


def shutdown():
    tracer_provider = api_trace.get_tracer_provider()
    tracer_provider.shutdown()

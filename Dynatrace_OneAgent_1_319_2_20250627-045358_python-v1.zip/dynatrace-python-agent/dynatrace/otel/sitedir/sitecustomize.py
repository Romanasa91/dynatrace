import atexit
import logging
import sys
from os import path

from dynatrace.opentelemetry.tracing._config.settings import DtConfig
from dynatrace.otel import agent
from dynatraceotel.util._importlib_metadata import EntryPoint, entry_points

logger = logging.getLogger("dynatrace.inject.agent")


def run_sitecustomize():
    this_dir = path.normcase(path.dirname(path.realpath(__file__)))
    try_next = False

    del sys.modules[__name__]
    if path.normcase(path.realpath(sys.path[0])) == this_dir:
        del sys.path[0]
        try_next = True

    try:
        setup_agent()
    except Exception as ex:  # pylint: disable=broad-except
        root_logger = logging.getLogger()
        root_logger.error("Failed to setup Dynatrace agent: %s", str(ex))

    # Try chain-loading other sitecustomize.
    # ImportError will be caught by the site module.
    if try_next:
        __import__("sitecustomize")


def setup_agent(**kwargs) -> agent.DynatraceAgent:
    agent_instance = agent.initialize(**kwargs)
    atexit.register(agent.shutdown)

    _setup_instrumentation_hooks(agent_instance.config)
    return agent_instance


def _setup_instrumentation_hooks(config: DtConfig) -> None:
    """Loads & sets up instrumentation hooks in group="dynatrace_instrumentation_hook".

    The names of the entry points should match with the instrumentation library
    name/scope without the "dt.agent.python." prefix.
    """
    unknown_sensors = set()
    entry_point: EntryPoint
    for entry_point in entry_points(group="dynatrace_instrumentation_hook"):
        name = entry_point.name
        try:
            if not config.sensors.is_known(name):
                unknown_sensors.add(name)
                continue

            if config.sensors.is_enabled(name):
                logger.debug("Hooking instrumentation '%s'", name)
                entry_point.load()().setup(logger)
            else:
                logger.debug(
                    "Not hooking instrumentation '%s' (disabled by config)",
                    name,
                )
        except Exception as ex:  # pylint: disable=broad-except
            logger.error(
                "Failed to setup instrumentation hook '%s': %s",
                name,
                str(ex),
            )

    if unknown_sensors:
        logger.warning(
            "Detected the following unknown sensors: %s",
            ", ".join(unknown_sensors),
        )


if __name__ == "sitecustomize":
    run_sitecustomize()

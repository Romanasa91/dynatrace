from typing import Optional

from dynatrace.opentelemetry.tracing._otel.api import (
    CarrierT,
    Context,
    Setter,
    default_setter,
    get_current_span,
)
from dynatrace.opentelemetry.tracing._propagator.textmap import (
    DtTextMapPropagator,
)
from dynatrace.otel.trace.provider import DtSuppressedSpan


class DtOdinTextMapPropagator(DtTextMapPropagator):
    def inject(
        self,
        carrier: CarrierT,
        context: Optional[Context] = None,
        setter: Setter = default_setter,
    ) -> None:
        span = get_current_span(context)
        if isinstance(span, DtSuppressedSpan):
            return

        super().inject(carrier, context, setter)

#!/bin/bash

# Check BASH_SOURCE to allow invoking the script directly so it always prints the version
# even if DT_LOGGING_DESTINATION is not set.
if [[ ! -z "$DT_LOGGING_DESTINATION" || "$0" = "$BASH_SOURCE" ]]; then
	echo "Dynatrace OneAgent python 1.319.2.20250627.045358"
	echo "Layerizer version: 1.29.110"
	echo "Copyright (C) 2012-2025 Dynatrace LLC. www.dynatrace.com"
fi

# Print additional debug information
if [[ ! -z "$DT_ENVIRONMENT_LOGGING" ]]; then
	echo "========= ENV ========="
	env
	echo "========= /ENV ========="
fi
